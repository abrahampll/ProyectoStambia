<?xml version="1.0" encoding="UTF-8"?>
<md:node xmlns:md="http://www.stambia.com/md" defType="com.stambia.flow" id="_UBrEcI6tEeuR9ojBhCRc5g-flow" name="Load CargaUniversoINI" md:ref="file:/C:/Users/D6855693/Documents/StambiaWorkspace_AZURE/.metadata/.plugins/com.indy.emf.uri/internalResource/technology/map/map.tech#_waYSMH8VEd2__Mzb_dB76A?fileId=_waYSMH8VEd2__Mzb_dB76A$type=tech$name=flow?">
  <node defType="com.stambia.flow.altId" id="_PlIWEZcQEeuuFLoH_iEI2Q">
    <attribute defType="com.stambia.flow.altId.origin" id="_PlIWEpcQEeuuFLoH_iEI2Q" value="mapping"/>
    <attribute defType="com.stambia.flow.altId.value" id="_PlIWE5cQEeuuFLoH_iEI2Q" value="_UBrEcI6tEeuR9ojBhCRc5g"/>
  </node>
  <node defType="com.stambia.flow.step" id="ec2a579a-9634-3586-821a-73620cd48dd4" name="I1_STB_PARAM_NASAZ_FILE">
    <attribute defType="com.stambia.flow.step.desc" id="_PlMngZcQEeuuFLoH_iEI2Q"/>
    <attribute defType="com.stambia.flow.step.type" id="_PlRgAJcQEeuuFLoH_iEI2Q" value="Integration"/>
    <attribute defType="com.stambia.flow.step.target" id="_PlRgAZcQEeuuFLoH_iEI2Q" value="$MD_0"/>
    <attribute defType="com.stambia.flow.step.srcProduct" id="_PlRgApcQEeuuFLoH_iEI2Q"/>
    <attribute defType="com.stambia.flow.step.trgProduct" id="_PlRgA5cQEeuuFLoH_iEI2Q" value="MICROSOFT_SQL_SERVER"/>
    <attribute defType="com.stambia.flow.step.tplCriteria" id="_PlRgBJcQEeuuFLoH_iEI2Q" value="type=I-TP;trgProduct=MICROSOFT_SQL_SERVER;trgPath=server:SQL_FILEDB/schema:filecloudDB.USTB00/datastore:STB_PARAM_NASAZ_FILE;trgWorkspaceCapability=true;trgMapCapability=true;trgFilterCapability=true;trgJoinCapability=true;srcProductList=MICROSOFT_SQL_SERVER"/>
    <attribute defType="com.stambia.flow.step.number" id="_PlSHEJcQEeuuFLoH_iEI2Q" value="1"/>
    <node defType="com.stambia.flow.source" id="_PldtWpcQEeuuFLoH_iEI2Q" name="STB_PARAM_NASAZURE">
      <attribute defType="com.stambia.flow.source.target" id="_PldtW5cQEeuuFLoH_iEI2Q" value="$MD_69"/>
    </node>
    <node defType="com.stambia.flow.source" id="_PldtXJcQEeuuFLoH_iEI2Q" name="IND_SESSION_FILE_OP_LST">
      <attribute defType="com.stambia.flow.source.target" id="_PldtXZcQEeuuFLoH_iEI2Q" value="$MD_70"/>
    </node>
    <node defType="com.stambia.flow.join" id="md__HvQTwI6xEeuR9ojBhCRc5g">
      <attribute defType="com.stambia.flow.join.left" id="_PldtUJcQEeuuFLoH_iEI2Q" value="STB_PARAM_NASAZURE"/>
      <attribute defType="com.stambia.flow.join.right" id="_PldtUZcQEeuuFLoH_iEI2Q" value="IND_SESSION_FILE_OP_LST"/>
      <attribute defType="com.stambia.flow.join.order" id="_PldtUpcQEeuuFLoH_iEI2Q" value="10"/>
      <attribute defType="com.stambia.flow.join.type" id="_PldtU5cQEeuuFLoH_iEI2Q" value="Inner_Join"/>
      <attribute defType="com.stambia.flow.join.tag" id="_PldtVJcQEeuuFLoH_iEI2Q"/>
      <attribute defType="com.stambia.flow.join.version" id="_PldtVZcQEeuuFLoH_iEI2Q" value="2"/>
      <attribute defType="com.stambia.flow.join.source" id="_PldtVpcQEeuuFLoH_iEI2Q">
        <values>$MD_16</values>
        <values>$MD_21</values>
        <values>$MD_18</values>
      </attribute>
      <attribute defType="com.stambia.flow.join.sourceNames" id="_PldtV5cQEeuuFLoH_iEI2Q">
        <values>STB_PARAM_NASAZURE.%{MD_21}%</values>
        <values>IND_SESSION_FILE_OP_LST.%{MD_18}%</values>
        <values>IND_SESSION_FILE_OP_LST.%{MD_16}%</values>
      </attribute>
      <attribute defType="com.stambia.flow.join.sourceContainer" id="_PldtWJcQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_LST</values>
        <values>STB_PARAM_NASAZURE</values>
      </attribute>
      <attribute defType="com.stambia.flow.join.expr" id="_PldtWZcQEeuuFLoH_iEI2Q" value="'STB_PARAM_NASAZURE.%{MD_21}% = SUBSTRING(IND_SESSION_FILE_OP_LST.%{MD_18}%,1,LEN(STB_PARAM_NASAZURE.%{MD_21}%))&#xA;and UPPER(RIGHT(IND_SESSION_FILE_OP_LST.%{MD_16}%,3)) = ''PDF''&#xA;&#xA;'"/>
    </node>
    <node defType="com.stambia.flow.field" id="_PlTVMJcQEeuuFLoH_iEI2Q" name="SESS_ID">
      <attribute defType="com.stambia.flow.field.tag" id="_PlTVMZcQEeuuFLoH_iEI2Q"/>
      <attribute defType="com.stambia.flow.field.workname" id="_PlTVMpcQEeuuFLoH_iEI2Q" value="SESS_ID"/>
      <attribute defType="com.stambia.flow.field.base" id="_PlTVM5cQEeuuFLoH_iEI2Q" value="$MD_1"/>
      <attribute defType="com.stambia.flow.field.target" id="_PlTVNJcQEeuuFLoH_iEI2Q" value="$MD_1"/>
      <attribute defType="com.stambia.flow.field.location" id="_PlTVNZcQEeuuFLoH_iEI2Q" value="SRC"/>
      <attribute defType="com.stambia.flow.field.version" id="_PlTVNpcQEeuuFLoH_iEI2Q" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_PlTVN5cQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_PlTVOJcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.source" id="_PlTVOZcQEeuuFLoH_iEI2Q">
        <values>$MD_2</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_PlaC4JcQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_LST.%{MD_2}%</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_PlaC4ZcQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_LST</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.expr" id="_PlaC4pcQEeuuFLoH_iEI2Q" value="'IND_SESSION_FILE_OP_LST.%{MD_2}%'"/>
    </node>
    <node defType="com.stambia.flow.field" id="_PlaC45cQEeuuFLoH_iEI2Q" name="SESS_NAME">
      <attribute defType="com.stambia.flow.field.tag" id="_PlaC5JcQEeuuFLoH_iEI2Q"/>
      <attribute defType="com.stambia.flow.field.workname" id="_PlaC5ZcQEeuuFLoH_iEI2Q" value="SESS_NAME"/>
      <attribute defType="com.stambia.flow.field.base" id="_PlaC5pcQEeuuFLoH_iEI2Q" value="$MD_3"/>
      <attribute defType="com.stambia.flow.field.target" id="_PlaC55cQEeuuFLoH_iEI2Q" value="$MD_3"/>
      <attribute defType="com.stambia.flow.field.location" id="_PlaC6JcQEeuuFLoH_iEI2Q" value="SRC"/>
      <attribute defType="com.stambia.flow.field.version" id="_PlaC6ZcQEeuuFLoH_iEI2Q" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_PlaC6pcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_PlaC65cQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.source" id="_PlaC7JcQEeuuFLoH_iEI2Q">
        <values>$MD_4</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_PlaC7ZcQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_LST.%{MD_4}%</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_PlaC7pcQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_LST</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.expr" id="_PlaC75cQEeuuFLoH_iEI2Q" value="'IND_SESSION_FILE_OP_LST.%{MD_4}%'"/>
    </node>
    <node defType="com.stambia.flow.field" id="_PlaC8JcQEeuuFLoH_iEI2Q" name="ACT_ID">
      <attribute defType="com.stambia.flow.field.tag" id="_PlaC8ZcQEeuuFLoH_iEI2Q"/>
      <attribute defType="com.stambia.flow.field.workname" id="_PlaC8pcQEeuuFLoH_iEI2Q" value="ACT_ID"/>
      <attribute defType="com.stambia.flow.field.base" id="_PlaC85cQEeuuFLoH_iEI2Q" value="$MD_5"/>
      <attribute defType="com.stambia.flow.field.target" id="_PlaC9JcQEeuuFLoH_iEI2Q" value="$MD_5"/>
      <attribute defType="com.stambia.flow.field.location" id="_PlaC9ZcQEeuuFLoH_iEI2Q" value="SRC"/>
      <attribute defType="com.stambia.flow.field.version" id="_PlaC9pcQEeuuFLoH_iEI2Q" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_PlaC95cQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_PlaC-JcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.source" id="_PlaC-ZcQEeuuFLoH_iEI2Q">
        <values>$MD_6</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_PlaC-pcQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_LST.%{MD_6}%</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_PlaC-5cQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_LST</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.expr" id="_PlaC_JcQEeuuFLoH_iEI2Q" value="'IND_SESSION_FILE_OP_LST.%{MD_6}%'"/>
    </node>
    <node defType="com.stambia.flow.field" id="_PlaC_ZcQEeuuFLoH_iEI2Q" name="ACT_NAME">
      <attribute defType="com.stambia.flow.field.tag" id="_PlaC_pcQEeuuFLoH_iEI2Q"/>
      <attribute defType="com.stambia.flow.field.workname" id="_PlaC_5cQEeuuFLoH_iEI2Q" value="ACT_NAME"/>
      <attribute defType="com.stambia.flow.field.base" id="_PlaDAJcQEeuuFLoH_iEI2Q" value="$MD_7"/>
      <attribute defType="com.stambia.flow.field.target" id="_PlaDAZcQEeuuFLoH_iEI2Q" value="$MD_7"/>
      <attribute defType="com.stambia.flow.field.location" id="_PlaDApcQEeuuFLoH_iEI2Q" value="SRC"/>
      <attribute defType="com.stambia.flow.field.version" id="_PlaDA5cQEeuuFLoH_iEI2Q" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_PlaDBJcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_PlaDBZcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.source" id="_PlaDBpcQEeuuFLoH_iEI2Q">
        <values>$MD_8</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_PlaDB5cQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_LST.%{MD_8}%</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_PlaDCJcQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_LST</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.expr" id="_PlaDCZcQEeuuFLoH_iEI2Q" value="'IND_SESSION_FILE_OP_LST.%{MD_8}%'"/>
    </node>
    <node defType="com.stambia.flow.field" id="_PlaDCpcQEeuuFLoH_iEI2Q" name="ACT_ITER">
      <attribute defType="com.stambia.flow.field.tag" id="_PlaDC5cQEeuuFLoH_iEI2Q"/>
      <attribute defType="com.stambia.flow.field.workname" id="_PlaDDJcQEeuuFLoH_iEI2Q" value="ACT_ITER"/>
      <attribute defType="com.stambia.flow.field.base" id="_PlaDDZcQEeuuFLoH_iEI2Q" value="$MD_9"/>
      <attribute defType="com.stambia.flow.field.target" id="_PlaDDpcQEeuuFLoH_iEI2Q" value="$MD_9"/>
      <attribute defType="com.stambia.flow.field.location" id="_PlaDD5cQEeuuFLoH_iEI2Q" value="SRC"/>
      <attribute defType="com.stambia.flow.field.version" id="_PlaDEJcQEeuuFLoH_iEI2Q" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_PlaDEZcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_PlaDEpcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.source" id="_PlaDE5cQEeuuFLoH_iEI2Q">
        <values>$MD_10</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_Plap8JcQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_LST.%{MD_10}%</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_Plap8ZcQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_LST</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.expr" id="_Plap8pcQEeuuFLoH_iEI2Q" value="'IND_SESSION_FILE_OP_LST.%{MD_10}%'"/>
    </node>
    <node defType="com.stambia.flow.field" id="_Plap85cQEeuuFLoH_iEI2Q" name="FILE_ID">
      <attribute defType="com.stambia.flow.field.tag" id="_Plap9JcQEeuuFLoH_iEI2Q"/>
      <attribute defType="com.stambia.flow.field.workname" id="_Plap9ZcQEeuuFLoH_iEI2Q" value="FILE_ID"/>
      <attribute defType="com.stambia.flow.field.base" id="_Plap9pcQEeuuFLoH_iEI2Q" value="$MD_11"/>
      <attribute defType="com.stambia.flow.field.target" id="_Plap95cQEeuuFLoH_iEI2Q" value="$MD_11"/>
      <attribute defType="com.stambia.flow.field.location" id="_Plap-JcQEeuuFLoH_iEI2Q" value="SRC"/>
      <attribute defType="com.stambia.flow.field.version" id="_Plap-ZcQEeuuFLoH_iEI2Q" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_Plap-pcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_Plap-5cQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.source" id="_Plap_JcQEeuuFLoH_iEI2Q">
        <values>$MD_12</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_Plap_ZcQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_LST.%{MD_12}%</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_Plap_pcQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_LST</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.expr" id="_Plap_5cQEeuuFLoH_iEI2Q" value="'IND_SESSION_FILE_OP_LST.%{MD_12}%'"/>
    </node>
    <node defType="com.stambia.flow.field" id="_PlaqAJcQEeuuFLoH_iEI2Q" name="FILE_OPERATION">
      <attribute defType="com.stambia.flow.field.tag" id="_PlaqAZcQEeuuFLoH_iEI2Q"/>
      <attribute defType="com.stambia.flow.field.workname" id="_PlaqApcQEeuuFLoH_iEI2Q" value="FILE_OPERATION"/>
      <attribute defType="com.stambia.flow.field.base" id="_PlaqA5cQEeuuFLoH_iEI2Q" value="$MD_13"/>
      <attribute defType="com.stambia.flow.field.target" id="_PlaqBJcQEeuuFLoH_iEI2Q" value="$MD_13"/>
      <attribute defType="com.stambia.flow.field.location" id="_PlaqBZcQEeuuFLoH_iEI2Q" value="SRC"/>
      <attribute defType="com.stambia.flow.field.version" id="_PlaqBpcQEeuuFLoH_iEI2Q" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_PlaqB5cQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_PlaqCJcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.source" id="_PlaqCZcQEeuuFLoH_iEI2Q">
        <values>$MD_14</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_PlaqCpcQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_LST.%{MD_14}%</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_PlaqC5cQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_LST</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.expr" id="_PlaqDJcQEeuuFLoH_iEI2Q" value="'IND_SESSION_FILE_OP_LST.%{MD_14}%'"/>
    </node>
    <node defType="com.stambia.flow.field" id="_PlaqDZcQEeuuFLoH_iEI2Q" name="FILE_NAME">
      <attribute defType="com.stambia.flow.field.tag" id="_PlaqDpcQEeuuFLoH_iEI2Q"/>
      <attribute defType="com.stambia.flow.field.workname" id="_PlaqD5cQEeuuFLoH_iEI2Q" value="FILE_NAME"/>
      <attribute defType="com.stambia.flow.field.base" id="_PlaqEJcQEeuuFLoH_iEI2Q" value="$MD_15"/>
      <attribute defType="com.stambia.flow.field.target" id="_PlaqEZcQEeuuFLoH_iEI2Q" value="$MD_15"/>
      <attribute defType="com.stambia.flow.field.location" id="_PlaqEpcQEeuuFLoH_iEI2Q" value="SRC"/>
      <attribute defType="com.stambia.flow.field.version" id="_PlaqE5cQEeuuFLoH_iEI2Q" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_PlaqFJcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_PlaqFZcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.updatekey" id="_PlaqFpcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.source" id="_PlaqF5cQEeuuFLoH_iEI2Q">
        <values>$MD_16</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_PlaqGJcQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_LST.%{MD_16}%</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_PlaqGZcQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_LST</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.expr" id="_PlaqGpcQEeuuFLoH_iEI2Q" value="'IND_SESSION_FILE_OP_LST.%{MD_16}%'"/>
    </node>
    <node defType="com.stambia.flow.field" id="_PlaqG5cQEeuuFLoH_iEI2Q" name="FILE_DIR">
      <attribute defType="com.stambia.flow.field.tag" id="_PlaqHJcQEeuuFLoH_iEI2Q"/>
      <attribute defType="com.stambia.flow.field.workname" id="_PlaqHZcQEeuuFLoH_iEI2Q" value="FILE_DIR"/>
      <attribute defType="com.stambia.flow.field.base" id="_PlaqHpcQEeuuFLoH_iEI2Q" value="$MD_17"/>
      <attribute defType="com.stambia.flow.field.target" id="_PlaqH5cQEeuuFLoH_iEI2Q" value="$MD_17"/>
      <attribute defType="com.stambia.flow.field.location" id="_PlaqIJcQEeuuFLoH_iEI2Q" value="SRC"/>
      <attribute defType="com.stambia.flow.field.version" id="_PlaqIZcQEeuuFLoH_iEI2Q" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_PlaqIpcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_PlaqI5cQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.updatekey" id="_PlaqJJcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.source" id="_PlaqJZcQEeuuFLoH_iEI2Q">
        <values>$MD_18</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_PlaqJpcQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_LST.%{MD_18}%</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_PlaqJ5cQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_LST</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.expr" id="_PlaqKJcQEeuuFLoH_iEI2Q" value="'IND_SESSION_FILE_OP_LST.%{MD_18}%'"/>
    </node>
    <node defType="com.stambia.flow.field" id="_PlaqKZcQEeuuFLoH_iEI2Q" name="ESTADO">
      <attribute defType="com.stambia.flow.field.tag" id="_PlaqKpcQEeuuFLoH_iEI2Q"/>
      <attribute defType="com.stambia.flow.field.workname" id="_PlaqK5cQEeuuFLoH_iEI2Q" value="ESTADO"/>
      <attribute defType="com.stambia.flow.field.base" id="_PlaqLJcQEeuuFLoH_iEI2Q" value="$MD_19"/>
      <attribute defType="com.stambia.flow.field.target" id="_PlaqLZcQEeuuFLoH_iEI2Q" value="$MD_19"/>
      <attribute defType="com.stambia.flow.field.location" id="_PlaqLpcQEeuuFLoH_iEI2Q" value="SRC"/>
      <attribute defType="com.stambia.flow.field.version" id="_PlaqL5cQEeuuFLoH_iEI2Q" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_PlaqMJcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_PlaqMZcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.expr" id="_PlaqMpcQEeuuFLoH_iEI2Q" value="'''Pendiente'''"/>
    </node>
    <node defType="com.stambia.flow.field" id="_PlaqM5cQEeuuFLoH_iEI2Q" name="RUTA_AZURE">
      <attribute defType="com.stambia.flow.field.tag" id="_PlaqNJcQEeuuFLoH_iEI2Q"/>
      <attribute defType="com.stambia.flow.field.workname" id="_PlaqNZcQEeuuFLoH_iEI2Q" value="RUTA_AZURE"/>
      <attribute defType="com.stambia.flow.field.base" id="_PlaqNpcQEeuuFLoH_iEI2Q" value="$MD_20"/>
      <attribute defType="com.stambia.flow.field.target" id="_PlaqN5cQEeuuFLoH_iEI2Q" value="$MD_20"/>
      <attribute defType="com.stambia.flow.field.location" id="_PlaqOJcQEeuuFLoH_iEI2Q" value="SRC"/>
      <attribute defType="com.stambia.flow.field.version" id="_PlaqOZcQEeuuFLoH_iEI2Q" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_PlaqOpcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_PlaqO5cQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.source" id="_PlaqPJcQEeuuFLoH_iEI2Q">
        <values>$MD_21</values>
        <values>$MD_22</values>
        <values>$MD_18</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_PlbRAJcQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_LST.%{MD_18}%</values>
        <values>STB_PARAM_NASAZURE.%{MD_21}%</values>
        <values>STB_PARAM_NASAZURE.%{MD_22}%</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_PlbRAZcQEeuuFLoH_iEI2Q">
        <values>STB_PARAM_NASAZURE</values>
        <values>IND_SESSION_FILE_OP_LST</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.expr" id="_PlbRApcQEeuuFLoH_iEI2Q" value="'REPLACE(IND_SESSION_FILE_OP_LST.%{MD_18}%,STB_PARAM_NASAZURE.%{MD_21}%,STB_PARAM_NASAZURE.%{MD_22}%)'"/>
    </node>
    <node defType="com.stambia.flow.field" id="_PlbRA5cQEeuuFLoH_iEI2Q" name="FILE_LENGTH">
      <attribute defType="com.stambia.flow.field.tag" id="_PlbRBJcQEeuuFLoH_iEI2Q"/>
      <attribute defType="com.stambia.flow.field.workname" id="_PlbRBZcQEeuuFLoH_iEI2Q" value="FILE_LENGTH"/>
      <attribute defType="com.stambia.flow.field.base" id="_PlbRBpcQEeuuFLoH_iEI2Q" value="$MD_24"/>
      <attribute defType="com.stambia.flow.field.target" id="_PlbRB5cQEeuuFLoH_iEI2Q" value="$MD_24"/>
      <attribute defType="com.stambia.flow.field.location" id="_PlbRCJcQEeuuFLoH_iEI2Q" value="SRC"/>
      <attribute defType="com.stambia.flow.field.version" id="_PlbRCZcQEeuuFLoH_iEI2Q" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_PlbRCpcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_PlbRC5cQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.source" id="_PlbRDJcQEeuuFLoH_iEI2Q">
        <values>$MD_25</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_PlbRDZcQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_LST.%{MD_25}%</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_PlbRDpcQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_LST</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.expr" id="_PlbRD5cQEeuuFLoH_iEI2Q" value="'IND_SESSION_FILE_OP_LST.%{MD_25}%'"/>
    </node>
    <node defType="com.stambia.flow.field" id="_PlbREJcQEeuuFLoH_iEI2Q" name="FILE_LAST_MODIFIED_DATE">
      <attribute defType="com.stambia.flow.field.tag" id="_PlbREZcQEeuuFLoH_iEI2Q"/>
      <attribute defType="com.stambia.flow.field.workname" id="_PlbREpcQEeuuFLoH_iEI2Q" value="FILE_LAST_MODIFIED_DATE"/>
      <attribute defType="com.stambia.flow.field.base" id="_PlbRE5cQEeuuFLoH_iEI2Q" value="$MD_26"/>
      <attribute defType="com.stambia.flow.field.target" id="_PlbRFJcQEeuuFLoH_iEI2Q" value="$MD_26"/>
      <attribute defType="com.stambia.flow.field.location" id="_PlbRFZcQEeuuFLoH_iEI2Q" value="SRC"/>
      <attribute defType="com.stambia.flow.field.version" id="_PlbRFpcQEeuuFLoH_iEI2Q" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_PlbRF5cQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_PlbRGJcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.source" id="_PlbRGZcQEeuuFLoH_iEI2Q">
        <values>$MD_27</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_PlbRGpcQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_LST.%{MD_27}%</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_PlbRG5cQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_LST</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.expr" id="_PlbRHJcQEeuuFLoH_iEI2Q" value="'IND_SESSION_FILE_OP_LST.%{MD_27}%'"/>
    </node>
    <node defType="com.stambia.flow.field" id="_PlbRHZcQEeuuFLoH_iEI2Q" name="FILE_TO_DIR">
      <attribute defType="com.stambia.flow.field.tag" id="_PlbRHpcQEeuuFLoH_iEI2Q"/>
      <attribute defType="com.stambia.flow.field.workname" id="_PlbRH5cQEeuuFLoH_iEI2Q" value="FILE_TO_DIR"/>
      <attribute defType="com.stambia.flow.field.base" id="_PlbRIJcQEeuuFLoH_iEI2Q" value="$MD_28"/>
      <attribute defType="com.stambia.flow.field.target" id="_PlbRIZcQEeuuFLoH_iEI2Q" value="$MD_28"/>
      <attribute defType="com.stambia.flow.field.location" id="_PlbRIpcQEeuuFLoH_iEI2Q" value="SRC"/>
      <attribute defType="com.stambia.flow.field.version" id="_PlbRI5cQEeuuFLoH_iEI2Q" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_PlbRJJcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_PlbRJZcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.source" id="_PlbRJpcQEeuuFLoH_iEI2Q">
        <values>$MD_29</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_PlbRJ5cQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_LST.%{MD_29}%</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_Plb4EJcQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_LST</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.expr" id="_Plb4EZcQEeuuFLoH_iEI2Q" value="'IND_SESSION_FILE_OP_LST.%{MD_29}%'"/>
    </node>
    <node defType="com.stambia.flow.field" id="_Plb4EpcQEeuuFLoH_iEI2Q" name="FILE_TO_FILE">
      <attribute defType="com.stambia.flow.field.tag" id="_Plb4E5cQEeuuFLoH_iEI2Q"/>
      <attribute defType="com.stambia.flow.field.workname" id="_Plb4FJcQEeuuFLoH_iEI2Q" value="FILE_TO_FILE"/>
      <attribute defType="com.stambia.flow.field.base" id="_Plb4FZcQEeuuFLoH_iEI2Q" value="$MD_30"/>
      <attribute defType="com.stambia.flow.field.target" id="_Plb4FpcQEeuuFLoH_iEI2Q" value="$MD_30"/>
      <attribute defType="com.stambia.flow.field.location" id="_Plb4F5cQEeuuFLoH_iEI2Q" value="SRC"/>
      <attribute defType="com.stambia.flow.field.version" id="_Plb4GJcQEeuuFLoH_iEI2Q" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_Plb4GZcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_Plb4GpcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.source" id="_Plb4G5cQEeuuFLoH_iEI2Q">
        <values>$MD_31</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_Plb4HJcQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_LST.%{MD_31}%</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_Plb4HZcQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_LST</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.expr" id="_Plb4HpcQEeuuFLoH_iEI2Q" value="'IND_SESSION_FILE_OP_LST.%{MD_31}%'"/>
    </node>
    <node defType="com.stambia.flow.field" id="_Plb4H5cQEeuuFLoH_iEI2Q" name="FILE_OPERATION_DATE">
      <attribute defType="com.stambia.flow.field.tag" id="_Plb4IJcQEeuuFLoH_iEI2Q"/>
      <attribute defType="com.stambia.flow.field.workname" id="_Plb4IZcQEeuuFLoH_iEI2Q" value="FILE_OPERATION_DATE"/>
      <attribute defType="com.stambia.flow.field.base" id="_Plb4IpcQEeuuFLoH_iEI2Q" value="$MD_32"/>
      <attribute defType="com.stambia.flow.field.target" id="_Plb4I5cQEeuuFLoH_iEI2Q" value="$MD_32"/>
      <attribute defType="com.stambia.flow.field.location" id="_Plb4JJcQEeuuFLoH_iEI2Q" value="SRC"/>
      <attribute defType="com.stambia.flow.field.version" id="_Plb4JZcQEeuuFLoH_iEI2Q" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_Plb4JpcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_Plb4J5cQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.source" id="_Plb4KJcQEeuuFLoH_iEI2Q">
        <values>$MD_33</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_Plb4KZcQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_LST.%{MD_33}%</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_Plb4KpcQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_LST</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.expr" id="_Plb4K5cQEeuuFLoH_iEI2Q" value="'IND_SESSION_FILE_OP_LST.%{MD_33}%'"/>
    </node>
    <node defType="com.stambia.flow.field" id="_Plb4LJcQEeuuFLoH_iEI2Q" name="STATUS">
      <attribute defType="com.stambia.flow.field.tag" id="_Plb4LZcQEeuuFLoH_iEI2Q"/>
      <attribute defType="com.stambia.flow.field.workname" id="_Plb4LpcQEeuuFLoH_iEI2Q" value="STATUS"/>
      <attribute defType="com.stambia.flow.field.base" id="_Plb4L5cQEeuuFLoH_iEI2Q" value="$MD_34"/>
      <attribute defType="com.stambia.flow.field.target" id="_Plb4MJcQEeuuFLoH_iEI2Q" value="$MD_34"/>
      <attribute defType="com.stambia.flow.field.location" id="_Plb4MZcQEeuuFLoH_iEI2Q" value="SRC"/>
      <attribute defType="com.stambia.flow.field.version" id="_Plb4MpcQEeuuFLoH_iEI2Q" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_Plb4M5cQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_Plb4NJcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.source" id="_Plb4NZcQEeuuFLoH_iEI2Q">
        <values>$MD_35</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_Plb4NpcQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_LST.%{MD_35}%</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_Plb4N5cQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_LST</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.expr" id="_Plb4OJcQEeuuFLoH_iEI2Q" value="'IND_SESSION_FILE_OP_LST.%{MD_35}%'"/>
    </node>
    <node defType="com.stambia.flow.field" id="_Plb4OZcQEeuuFLoH_iEI2Q" name="STATUS_COMMENT">
      <attribute defType="com.stambia.flow.field.tag" id="_Plb4OpcQEeuuFLoH_iEI2Q"/>
      <attribute defType="com.stambia.flow.field.workname" id="_Plb4O5cQEeuuFLoH_iEI2Q" value="STATUS_COMMENT"/>
      <attribute defType="com.stambia.flow.field.base" id="_Plb4PJcQEeuuFLoH_iEI2Q" value="$MD_36"/>
      <attribute defType="com.stambia.flow.field.target" id="_Plb4PZcQEeuuFLoH_iEI2Q" value="$MD_36"/>
      <attribute defType="com.stambia.flow.field.location" id="_Plb4PpcQEeuuFLoH_iEI2Q" value="SRC"/>
      <attribute defType="com.stambia.flow.field.version" id="_Plb4P5cQEeuuFLoH_iEI2Q" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_Plb4QJcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_Plb4QZcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.source" id="_Plb4QpcQEeuuFLoH_iEI2Q">
        <values>$MD_37</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_Plb4Q5cQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_LST.%{MD_37}%</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_Plb4RJcQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_LST</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.expr" id="_Plb4RZcQEeuuFLoH_iEI2Q" value="'IND_SESSION_FILE_OP_LST.%{MD_37}%'"/>
    </node>
    <node defType="com.stambia.flow.field" id="_Plb4RpcQEeuuFLoH_iEI2Q" name="STATUS_DATE">
      <attribute defType="com.stambia.flow.field.tag" id="_Plb4R5cQEeuuFLoH_iEI2Q"/>
      <attribute defType="com.stambia.flow.field.workname" id="_Plb4SJcQEeuuFLoH_iEI2Q" value="STATUS_DATE"/>
      <attribute defType="com.stambia.flow.field.base" id="_Plb4SZcQEeuuFLoH_iEI2Q" value="$MD_38"/>
      <attribute defType="com.stambia.flow.field.target" id="_Plb4SpcQEeuuFLoH_iEI2Q" value="$MD_38"/>
      <attribute defType="com.stambia.flow.field.location" id="_Plb4S5cQEeuuFLoH_iEI2Q" value="SRC"/>
      <attribute defType="com.stambia.flow.field.version" id="_Plb4TJcQEeuuFLoH_iEI2Q" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_Plb4TZcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_Plb4TpcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.source" id="_Plb4T5cQEeuuFLoH_iEI2Q">
        <values>$MD_39</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_Plb4UJcQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_LST.%{MD_39}%</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_Plb4UZcQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_LST</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.expr" id="_Plb4UpcQEeuuFLoH_iEI2Q" value="'IND_SESSION_FILE_OP_LST.%{MD_39}%'"/>
    </node>
    <node defType="com.stambia.flow.field" id="_Plb4U5cQEeuuFLoH_iEI2Q" name="USER_COMMENT">
      <attribute defType="com.stambia.flow.field.tag" id="_Plb4VJcQEeuuFLoH_iEI2Q"/>
      <attribute defType="com.stambia.flow.field.workname" id="_Plb4VZcQEeuuFLoH_iEI2Q" value="USER_COMMENT"/>
      <attribute defType="com.stambia.flow.field.base" id="_Plb4VpcQEeuuFLoH_iEI2Q" value="$MD_40"/>
      <attribute defType="com.stambia.flow.field.target" id="_Plb4V5cQEeuuFLoH_iEI2Q" value="$MD_40"/>
      <attribute defType="com.stambia.flow.field.location" id="_Plb4WJcQEeuuFLoH_iEI2Q" value="SRC"/>
      <attribute defType="com.stambia.flow.field.version" id="_Plb4WZcQEeuuFLoH_iEI2Q" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_Plb4WpcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_Plb4W5cQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.source" id="_Plb4XJcQEeuuFLoH_iEI2Q">
        <values>$MD_41</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_PlcfIJcQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_LST.%{MD_41}%</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_PlcfIZcQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_LST</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.expr" id="_PlcfIpcQEeuuFLoH_iEI2Q" value="'IND_SESSION_FILE_OP_LST.%{MD_41}%'"/>
    </node>
    <node defType="com.stambia.flow.field" id="_PlcfI5cQEeuuFLoH_iEI2Q" name="USER_FLAG">
      <attribute defType="com.stambia.flow.field.tag" id="_PlcfJJcQEeuuFLoH_iEI2Q"/>
      <attribute defType="com.stambia.flow.field.workname" id="_PlcfJZcQEeuuFLoH_iEI2Q" value="USER_FLAG"/>
      <attribute defType="com.stambia.flow.field.base" id="_PlcfJpcQEeuuFLoH_iEI2Q" value="$MD_42"/>
      <attribute defType="com.stambia.flow.field.target" id="_PlcfJ5cQEeuuFLoH_iEI2Q" value="$MD_42"/>
      <attribute defType="com.stambia.flow.field.location" id="_PlcfKJcQEeuuFLoH_iEI2Q" value="SRC"/>
      <attribute defType="com.stambia.flow.field.version" id="_PlcfKZcQEeuuFLoH_iEI2Q" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_PlcfKpcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_PlcfK5cQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.source" id="_PlcfLJcQEeuuFLoH_iEI2Q">
        <values>$MD_43</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_PlcfLZcQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_LST.%{MD_43}%</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_PlcfLpcQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_LST</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.expr" id="_PlcfL5cQEeuuFLoH_iEI2Q" value="'IND_SESSION_FILE_OP_LST.%{MD_43}%'"/>
    </node>
    <node defType="com.stambia.flow.field" id="_PlcfMJcQEeuuFLoH_iEI2Q" name="USER_DATE">
      <attribute defType="com.stambia.flow.field.tag" id="_PlcfMZcQEeuuFLoH_iEI2Q"/>
      <attribute defType="com.stambia.flow.field.workname" id="_PlcfMpcQEeuuFLoH_iEI2Q" value="USER_DATE"/>
      <attribute defType="com.stambia.flow.field.base" id="_PlcfM5cQEeuuFLoH_iEI2Q" value="$MD_44"/>
      <attribute defType="com.stambia.flow.field.target" id="_PlcfNJcQEeuuFLoH_iEI2Q" value="$MD_44"/>
      <attribute defType="com.stambia.flow.field.location" id="_PlcfNZcQEeuuFLoH_iEI2Q" value="SRC"/>
      <attribute defType="com.stambia.flow.field.version" id="_PlcfNpcQEeuuFLoH_iEI2Q" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_PlcfN5cQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_PlcfOJcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.source" id="_PlcfOZcQEeuuFLoH_iEI2Q">
        <values>$MD_45</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_PlcfOpcQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_LST.%{MD_45}%</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_PlcfO5cQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_LST</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.expr" id="_PlcfPJcQEeuuFLoH_iEI2Q" value="'IND_SESSION_FILE_OP_LST.%{MD_45}%'"/>
    </node>
    <node defType="com.stambia.flow.field" id="_PlcfPZcQEeuuFLoH_iEI2Q" name="FILE_IS_HIDDEN">
      <attribute defType="com.stambia.flow.field.tag" id="_PlcfPpcQEeuuFLoH_iEI2Q"/>
      <attribute defType="com.stambia.flow.field.workname" id="_PlcfP5cQEeuuFLoH_iEI2Q" value="FILE_IS_HIDDEN"/>
      <attribute defType="com.stambia.flow.field.base" id="_PlcfQJcQEeuuFLoH_iEI2Q" value="$MD_46"/>
      <attribute defType="com.stambia.flow.field.target" id="_PlcfQZcQEeuuFLoH_iEI2Q" value="$MD_46"/>
      <attribute defType="com.stambia.flow.field.location" id="_PlcfQpcQEeuuFLoH_iEI2Q" value="SRC"/>
      <attribute defType="com.stambia.flow.field.version" id="_PlcfQ5cQEeuuFLoH_iEI2Q" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_PlcfRJcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_PlcfRZcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.source" id="_PlcfRpcQEeuuFLoH_iEI2Q">
        <values>$MD_47</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_PlcfR5cQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_LST.%{MD_47}%</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_PlcfSJcQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_LST</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.expr" id="_PlcfSZcQEeuuFLoH_iEI2Q" value="'IND_SESSION_FILE_OP_LST.%{MD_47}%'"/>
    </node>
    <node defType="com.stambia.flow.field" id="_PlcfSpcQEeuuFLoH_iEI2Q" name="FILE_LAST_MODIFIED">
      <attribute defType="com.stambia.flow.field.tag" id="_PlcfS5cQEeuuFLoH_iEI2Q"/>
      <attribute defType="com.stambia.flow.field.workname" id="_PlcfTJcQEeuuFLoH_iEI2Q" value="FILE_LAST_MODIFIED"/>
      <attribute defType="com.stambia.flow.field.base" id="_PlcfTZcQEeuuFLoH_iEI2Q" value="$MD_48"/>
      <attribute defType="com.stambia.flow.field.target" id="_PlcfTpcQEeuuFLoH_iEI2Q" value="$MD_48"/>
      <attribute defType="com.stambia.flow.field.location" id="_PlcfT5cQEeuuFLoH_iEI2Q" value="SRC"/>
      <attribute defType="com.stambia.flow.field.version" id="_PlcfUJcQEeuuFLoH_iEI2Q" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_PlcfUZcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_PlcfUpcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.source" id="_PlcfU5cQEeuuFLoH_iEI2Q">
        <values>$MD_49</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_PlcfVJcQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_LST.%{MD_49}%</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_PlcfVZcQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_LST</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.expr" id="_PlcfVpcQEeuuFLoH_iEI2Q" value="'IND_SESSION_FILE_OP_LST.%{MD_49}%'"/>
    </node>
    <node defType="com.stambia.flow.field" id="_PlcfV5cQEeuuFLoH_iEI2Q" name="FILE_CAN_READ">
      <attribute defType="com.stambia.flow.field.tag" id="_PlcfWJcQEeuuFLoH_iEI2Q"/>
      <attribute defType="com.stambia.flow.field.workname" id="_PlcfWZcQEeuuFLoH_iEI2Q" value="FILE_CAN_READ"/>
      <attribute defType="com.stambia.flow.field.base" id="_PlcfWpcQEeuuFLoH_iEI2Q" value="$MD_50"/>
      <attribute defType="com.stambia.flow.field.target" id="_PlcfW5cQEeuuFLoH_iEI2Q" value="$MD_50"/>
      <attribute defType="com.stambia.flow.field.location" id="_PlcfXJcQEeuuFLoH_iEI2Q" value="SRC"/>
      <attribute defType="com.stambia.flow.field.version" id="_PlcfXZcQEeuuFLoH_iEI2Q" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_PlcfXpcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_PlcfX5cQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.source" id="_PlcfYJcQEeuuFLoH_iEI2Q">
        <values>$MD_51</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_PlcfYZcQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_LST.%{MD_51}%</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_PlcfYpcQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_LST</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.expr" id="_PlcfY5cQEeuuFLoH_iEI2Q" value="'IND_SESSION_FILE_OP_LST.%{MD_51}%'"/>
    </node>
    <node defType="com.stambia.flow.field" id="_PlcfZJcQEeuuFLoH_iEI2Q" name="FILE_CAN_WRITE">
      <attribute defType="com.stambia.flow.field.tag" id="_PlcfZZcQEeuuFLoH_iEI2Q"/>
      <attribute defType="com.stambia.flow.field.workname" id="_PlcfZpcQEeuuFLoH_iEI2Q" value="FILE_CAN_WRITE"/>
      <attribute defType="com.stambia.flow.field.base" id="_PlcfZ5cQEeuuFLoH_iEI2Q" value="$MD_52"/>
      <attribute defType="com.stambia.flow.field.target" id="_PlcfaJcQEeuuFLoH_iEI2Q" value="$MD_52"/>
      <attribute defType="com.stambia.flow.field.location" id="_PlcfaZcQEeuuFLoH_iEI2Q" value="SRC"/>
      <attribute defType="com.stambia.flow.field.version" id="_PlcfapcQEeuuFLoH_iEI2Q" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_Plcfa5cQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_PlcfbJcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.source" id="_PlcfbZcQEeuuFLoH_iEI2Q">
        <values>$MD_53</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_PldGMJcQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_LST.%{MD_53}%</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_PldGMZcQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_LST</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.expr" id="_PldGMpcQEeuuFLoH_iEI2Q" value="'IND_SESSION_FILE_OP_LST.%{MD_53}%'"/>
    </node>
    <node defType="com.stambia.flow.field" id="_PldGM5cQEeuuFLoH_iEI2Q" name="FILE_CAN_EXECUTE">
      <attribute defType="com.stambia.flow.field.tag" id="_PldGNJcQEeuuFLoH_iEI2Q"/>
      <attribute defType="com.stambia.flow.field.workname" id="_PldGNZcQEeuuFLoH_iEI2Q" value="FILE_CAN_EXECUTE"/>
      <attribute defType="com.stambia.flow.field.base" id="_PldGNpcQEeuuFLoH_iEI2Q" value="$MD_54"/>
      <attribute defType="com.stambia.flow.field.target" id="_PldGN5cQEeuuFLoH_iEI2Q" value="$MD_54"/>
      <attribute defType="com.stambia.flow.field.location" id="_PldGOJcQEeuuFLoH_iEI2Q" value="SRC"/>
      <attribute defType="com.stambia.flow.field.version" id="_PldGOZcQEeuuFLoH_iEI2Q" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_PldGOpcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_PldGO5cQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.source" id="_PldGPJcQEeuuFLoH_iEI2Q">
        <values>$MD_55</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_PldGPZcQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_LST.%{MD_55}%</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_PldGPpcQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_LST</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.expr" id="_PldGP5cQEeuuFLoH_iEI2Q" value="'IND_SESSION_FILE_OP_LST.%{MD_55}%'"/>
    </node>
    <node defType="com.stambia.flow.field" id="_PldGQJcQEeuuFLoH_iEI2Q" name="FILE_IS_DIRECTORY">
      <attribute defType="com.stambia.flow.field.tag" id="_PldGQZcQEeuuFLoH_iEI2Q"/>
      <attribute defType="com.stambia.flow.field.workname" id="_PldGQpcQEeuuFLoH_iEI2Q" value="FILE_IS_DIRECTORY"/>
      <attribute defType="com.stambia.flow.field.base" id="_PldGQ5cQEeuuFLoH_iEI2Q" value="$MD_56"/>
      <attribute defType="com.stambia.flow.field.target" id="_PldGRJcQEeuuFLoH_iEI2Q" value="$MD_56"/>
      <attribute defType="com.stambia.flow.field.location" id="_PldGRZcQEeuuFLoH_iEI2Q" value="SRC"/>
      <attribute defType="com.stambia.flow.field.version" id="_PldGRpcQEeuuFLoH_iEI2Q" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_PldGR5cQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_PldGSJcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.source" id="_PldGSZcQEeuuFLoH_iEI2Q">
        <values>$MD_57</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_PldGSpcQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_LST.%{MD_57}%</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_PldGS5cQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_LST</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.expr" id="_PldGTJcQEeuuFLoH_iEI2Q" value="'IND_SESSION_FILE_OP_LST.%{MD_57}%'"/>
    </node>
    <node defType="com.stambia.flow.field" id="_PldGTZcQEeuuFLoH_iEI2Q" name="FILE_FROM_DIR">
      <attribute defType="com.stambia.flow.field.tag" id="_PldGTpcQEeuuFLoH_iEI2Q"/>
      <attribute defType="com.stambia.flow.field.workname" id="_PldGT5cQEeuuFLoH_iEI2Q" value="FILE_FROM_DIR"/>
      <attribute defType="com.stambia.flow.field.base" id="_PldGUJcQEeuuFLoH_iEI2Q" value="$MD_58"/>
      <attribute defType="com.stambia.flow.field.target" id="_PldGUZcQEeuuFLoH_iEI2Q" value="$MD_58"/>
      <attribute defType="com.stambia.flow.field.location" id="_PldGUpcQEeuuFLoH_iEI2Q" value="SRC"/>
      <attribute defType="com.stambia.flow.field.version" id="_PldGU5cQEeuuFLoH_iEI2Q" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_PldGVJcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_PldGVZcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.source" id="_PldGVpcQEeuuFLoH_iEI2Q">
        <values>$MD_59</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_PldGV5cQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_LST.%{MD_59}%</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_PldGWJcQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_LST</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.expr" id="_PldGWZcQEeuuFLoH_iEI2Q" value="'IND_SESSION_FILE_OP_LST.%{MD_59}%'"/>
    </node>
    <node defType="com.stambia.flow.field" id="_PldGWpcQEeuuFLoH_iEI2Q" name="FILE_FROM_FILE">
      <attribute defType="com.stambia.flow.field.tag" id="_PldGW5cQEeuuFLoH_iEI2Q"/>
      <attribute defType="com.stambia.flow.field.workname" id="_PldGXJcQEeuuFLoH_iEI2Q" value="FILE_FROM_FILE"/>
      <attribute defType="com.stambia.flow.field.base" id="_PldGXZcQEeuuFLoH_iEI2Q" value="$MD_60"/>
      <attribute defType="com.stambia.flow.field.target" id="_PldGXpcQEeuuFLoH_iEI2Q" value="$MD_60"/>
      <attribute defType="com.stambia.flow.field.location" id="_PldGX5cQEeuuFLoH_iEI2Q" value="SRC"/>
      <attribute defType="com.stambia.flow.field.version" id="_PldGYJcQEeuuFLoH_iEI2Q" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_PldGYZcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_PldGYpcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.source" id="_PldGY5cQEeuuFLoH_iEI2Q">
        <values>$MD_61</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_PldGZJcQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_LST.%{MD_61}%</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_PldGZZcQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_LST</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.expr" id="_PldGZpcQEeuuFLoH_iEI2Q" value="'IND_SESSION_FILE_OP_LST.%{MD_61}%'"/>
    </node>
    <node defType="com.stambia.flow.field" id="_PldGZ5cQEeuuFLoH_iEI2Q" name="BORRADOLOCAL">
      <attribute defType="com.stambia.flow.field.tag" id="_PldGaJcQEeuuFLoH_iEI2Q"/>
      <attribute defType="com.stambia.flow.field.workname" id="_PldGaZcQEeuuFLoH_iEI2Q" value="BORRADOLOCAL"/>
      <attribute defType="com.stambia.flow.field.base" id="_PldGapcQEeuuFLoH_iEI2Q" value="$MD_62"/>
      <attribute defType="com.stambia.flow.field.target" id="_PldGa5cQEeuuFLoH_iEI2Q" value="$MD_62"/>
      <attribute defType="com.stambia.flow.field.location" id="_PldGbJcQEeuuFLoH_iEI2Q" value="SRC"/>
      <attribute defType="com.stambia.flow.field.version" id="_PldGbZcQEeuuFLoH_iEI2Q" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_PldGbpcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_PldGb5cQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.source" id="_PldGcJcQEeuuFLoH_iEI2Q">
        <values>$MD_63</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_PldGcZcQEeuuFLoH_iEI2Q">
        <values>STB_PARAM_NASAZURE.%{MD_63}%</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_PldtQJcQEeuuFLoH_iEI2Q">
        <values>STB_PARAM_NASAZURE</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.expr" id="_PldtQZcQEeuuFLoH_iEI2Q" value="'STB_PARAM_NASAZURE.%{MD_63}%'"/>
    </node>
    <node defType="com.stambia.flow.field" id="_PldtQpcQEeuuFLoH_iEI2Q" name="BORRADONUBE">
      <attribute defType="com.stambia.flow.field.tag" id="_PldtQ5cQEeuuFLoH_iEI2Q"/>
      <attribute defType="com.stambia.flow.field.workname" id="_PldtRJcQEeuuFLoH_iEI2Q" value="BORRADONUBE"/>
      <attribute defType="com.stambia.flow.field.base" id="_PldtRZcQEeuuFLoH_iEI2Q" value="$MD_64"/>
      <attribute defType="com.stambia.flow.field.target" id="_PldtRpcQEeuuFLoH_iEI2Q" value="$MD_64"/>
      <attribute defType="com.stambia.flow.field.location" id="_PldtR5cQEeuuFLoH_iEI2Q" value="SRC"/>
      <attribute defType="com.stambia.flow.field.version" id="_PldtSJcQEeuuFLoH_iEI2Q" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_PldtSZcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_PldtSpcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.source" id="_PldtS5cQEeuuFLoH_iEI2Q">
        <values>$MD_65</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_PldtTJcQEeuuFLoH_iEI2Q">
        <values>STB_PARAM_NASAZURE.%{MD_65}%</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_PldtTZcQEeuuFLoH_iEI2Q">
        <values>STB_PARAM_NASAZURE</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.expr" id="_PldtTpcQEeuuFLoH_iEI2Q" value="'STB_PARAM_NASAZURE.%{MD_65}%'"/>
    </node>
  </node>
  <metaDataLink name="MD_0" target="../../Metadata/SQL_FILEDB.md#_dpGGMZBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=STB_PARAM_NASAZ_FILE?"/>
  <metaDataLink name="MD_1" target="../../Metadata/SQL_FILEDB.md#_dpP3MJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=SESS_ID?"/>
  <metaDataLink name="MD_2" target="../../Metadata/SQL_FILEDB.md#_dm9YMJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=SESS_ID?"/>
  <metaDataLink name="MD_3" target="../../Metadata/SQL_FILEDB.md#_dpRsYJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=SESS_NAME?"/>
  <metaDataLink name="MD_4" target="../../Metadata/SQL_FILEDB.md#_dnC3wJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=SESS_NAME?"/>
  <metaDataLink name="MD_5" target="../../Metadata/SQL_FILEDB.md#_dpThkJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=ACT_ID?"/>
  <metaDataLink name="MD_6" target="../../Metadata/SQL_FILEDB.md#_dnF7EJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=ACT_ID?"/>
  <metaDataLink name="MD_7" target="../../Metadata/SQL_FILEDB.md#_dpVWwJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=ACT_NAME?"/>
  <metaDataLink name="MD_8" target="../../Metadata/SQL_FILEDB.md#_dnI-YJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=ACT_NAME?"/>
  <metaDataLink name="MD_9" target="../../Metadata/SQL_FILEDB.md#_dpXL8JBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=ACT_ITER?"/>
  <metaDataLink name="MD_10" target="../../Metadata/SQL_FILEDB.md#_dnMowJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=ACT_ITER?"/>
  <metaDataLink name="MD_11" target="../../Metadata/SQL_FILEDB.md#_dpZBIJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=FILE_ID?"/>
  <metaDataLink name="MD_12" target="../../Metadata/SQL_FILEDB.md#_dnPsEJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=FILE_ID?"/>
  <metaDataLink name="MD_13" target="../../Metadata/SQL_FILEDB.md#_dpa2UJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=FILE_OPERATION?"/>
  <metaDataLink name="MD_14" target="../../Metadata/SQL_FILEDB.md#_dnSIUJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=FILE_OPERATION?"/>
  <metaDataLink name="MD_15" target="../../Metadata/SQL_FILEDB.md#_dpcEcJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=FILE_NAME?"/>
  <metaDataLink name="MD_16" target="../../Metadata/SQL_FILEDB.md#_dnUkkJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=FILE_NAME?"/>
  <metaDataLink name="MD_17" target="../../Metadata/SQL_FILEDB.md#_dpegsJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=FILE_DIR?"/>
  <metaDataLink name="MD_18" target="../../Metadata/SQL_FILEDB.md#_dnXA0JBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=FILE_DIR?"/>
  <metaDataLink name="MD_19" target="../../Metadata/SQL_FILEDB.md#_dpfu0JBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=ESTADO?"/>
  <metaDataLink name="MD_20" target="../../Metadata/SQL_FILEDB.md#_dphkAJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=RUTA_AZURE?"/>
  <metaDataLink name="MD_21" target="../../Metadata/SQL_FILEDB.md#_do0ZYJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=NOMCARPETA?"/>
  <metaDataLink name="MD_22" target="../../Metadata/SQL_FILEDB.md#_do8VMJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=RUTACLOUD?"/>
  <metaDataLink name="MD_24" target="../../Metadata/SQL_FILEDB.md#_dpjZMJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=FILE_LENGTH?"/>
  <metaDataLink name="MD_25" target="../../Metadata/SQL_FILEDB.md#_doCWQJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=FILE_LENGTH?"/>
  <metaDataLink name="MD_26" target="../../Metadata/SQL_FILEDB.md#_dplOYJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=FILE_LAST_MODIFIED_DATE?"/>
  <metaDataLink name="MD_27" target="../../Metadata/SQL_FILEDB.md#_dn3-MJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=FILE_LAST_MODIFIED_DATE?"/>
  <metaDataLink name="MD_28" target="../../Metadata/SQL_FILEDB.md#_dpmcgJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=FILE_TO_DIR?"/>
  <metaDataLink name="MD_29" target="../../Metadata/SQL_FILEDB.md#_dne8oJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=FILE_TO_DIR?"/>
  <metaDataLink name="MD_30" target="../../Metadata/SQL_FILEDB.md#_dpoRsJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=FILE_TO_FILE?"/>
  <metaDataLink name="MD_31" target="../../Metadata/SQL_FILEDB.md#_dnhY4JBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=FILE_TO_FILE?"/>
  <metaDataLink name="MD_32" target="../../Metadata/SQL_FILEDB.md#_dpqG4JBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=FILE_OPERATION_DATE?"/>
  <metaDataLink name="MD_33" target="../../Metadata/SQL_FILEDB.md#_dnjOEJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=FILE_OPERATION_DATE?"/>
  <metaDataLink name="MD_34" target="../../Metadata/SQL_FILEDB.md#_dpr8EJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=STATUS?"/>
  <metaDataLink name="MD_35" target="../../Metadata/SQL_FILEDB.md#_dnlqUJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=STATUS?"/>
  <metaDataLink name="MD_36" target="../../Metadata/SQL_FILEDB.md#_dptxQJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=STATUS_COMMENT?"/>
  <metaDataLink name="MD_37" target="../../Metadata/SQL_FILEDB.md#_dnnfgJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=STATUS_COMMENT?"/>
  <metaDataLink name="MD_38" target="../../Metadata/SQL_FILEDB.md#_dpvmcJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=STATUS_DATE?"/>
  <metaDataLink name="MD_39" target="../../Metadata/SQL_FILEDB.md#_dnp7wJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=STATUS_DATE?"/>
  <metaDataLink name="MD_40" target="../../Metadata/SQL_FILEDB.md#_dpw0kJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=USER_COMMENT?"/>
  <metaDataLink name="MD_41" target="../../Metadata/SQL_FILEDB.md#_dnsYAJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=USER_COMMENT?"/>
  <metaDataLink name="MD_42" target="../../Metadata/SQL_FILEDB.md#_dpypwJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=USER_FLAG?"/>
  <metaDataLink name="MD_43" target="../../Metadata/SQL_FILEDB.md#_dnu0QJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=USER_FLAG?"/>
  <metaDataLink name="MD_44" target="../../Metadata/SQL_FILEDB.md#_dpz34JBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=USER_DATE?"/>
  <metaDataLink name="MD_45" target="../../Metadata/SQL_FILEDB.md#_dnxQgJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=USER_DATE?"/>
  <metaDataLink name="MD_46" target="../../Metadata/SQL_FILEDB.md#_dp1tEJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=FILE_IS_HIDDEN?"/>
  <metaDataLink name="MD_47" target="../../Metadata/SQL_FILEDB.md#_dnzFsJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=FILE_IS_HIDDEN?"/>
  <metaDataLink name="MD_48" target="../../Metadata/SQL_FILEDB.md#_dp3iQJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=FILE_LAST_MODIFIED?"/>
  <metaDataLink name="MD_49" target="../../Metadata/SQL_FILEDB.md#_dn1h8JBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=FILE_LAST_MODIFIED?"/>
  <metaDataLink name="MD_50" target="../../Metadata/SQL_FILEDB.md#_dp4wYJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=FILE_CAN_READ?"/>
  <metaDataLink name="MD_51" target="../../Metadata/SQL_FILEDB.md#_dn5zYJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=FILE_CAN_READ?"/>
  <metaDataLink name="MD_52" target="../../Metadata/SQL_FILEDB.md#_dp6lkJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=FILE_CAN_WRITE?"/>
  <metaDataLink name="MD_53" target="../../Metadata/SQL_FILEDB.md#_dn7okJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=FILE_CAN_WRITE?"/>
  <metaDataLink name="MD_54" target="../../Metadata/SQL_FILEDB.md#_dp8awJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=FILE_CAN_EXECUTE?"/>
  <metaDataLink name="MD_55" target="../../Metadata/SQL_FILEDB.md#_dn-E0JBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=FILE_CAN_EXECUTE?"/>
  <metaDataLink name="MD_56" target="../../Metadata/SQL_FILEDB.md#_dp-P8JBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=FILE_IS_DIRECTORY?"/>
  <metaDataLink name="MD_57" target="../../Metadata/SQL_FILEDB.md#_dn_6AJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=FILE_IS_DIRECTORY?"/>
  <metaDataLink name="MD_58" target="../../Metadata/SQL_FILEDB.md#_dqPVsJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=FILE_FROM_DIR?"/>
  <metaDataLink name="MD_59" target="../../Metadata/SQL_FILEDB.md#_dnaEIJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=FILE_FROM_DIR?"/>
  <metaDataLink name="MD_60" target="../../Metadata/SQL_FILEDB.md#_dqRK4JBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=FILE_FROM_FILE?"/>
  <metaDataLink name="MD_61" target="../../Metadata/SQL_FILEDB.md#_dncgYJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=FILE_FROM_FILE?"/>
  <metaDataLink name="MD_62" target="../../Metadata/SQL_FILEDB.md#_yfvY8JDoEeu9G7DSepCQHA?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=BORRADOLOCAL?"/>
  <metaDataLink name="MD_63" target="../../Metadata/SQL_FILEDB.md#_do4q0JBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=BORRADOLOCAL?"/>
  <metaDataLink name="MD_64" target="../../Metadata/SQL_FILEDB.md#_yfxOIJDoEeu9G7DSepCQHA?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=BORRADONUBE?"/>
  <metaDataLink name="MD_65" target="../../Metadata/SQL_FILEDB.md#_do6gAJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=BORRADONUBE?"/>
  <metaDataLink name="MD_69" target="../../Metadata/SQL_FILEDB.md#_dotrsZBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=STB_PARAM_NASAZURE?"/>
  <metaDataLink name="MD_70" target="../../Metadata/SQL_FILEDB.md#_dmmL0JBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=IND_SESSION_FILE_OP_LST?"/>
</md:node>