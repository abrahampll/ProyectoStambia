<?xml version="1.0" encoding="UTF-8"?>
<md:node xmlns:md="http://www.stambia.com/md" defType="com.stambia.flow" id="_aTYA8I6KEeuY0umjNgUiVA-flow" name="Load CargaInicial" md:ref="file:/C:/Users/D6855693/Documents/StambiaWorkspace_AZURE/.metadata/.plugins/com.indy.emf.uri/internalResource/technology/map/map.tech#_waYSMH8VEd2__Mzb_dB76A?fileId=_waYSMH8VEd2__Mzb_dB76A$type=tech$name=flow?">
  <node defType="com.stambia.flow.altId" id="_PmC8EZcQEeuuFLoH_iEI2Q">
    <attribute defType="com.stambia.flow.altId.origin" id="_PmDjIJcQEeuuFLoH_iEI2Q" value="mapping"/>
    <attribute defType="com.stambia.flow.altId.value" id="_PmDjIZcQEeuuFLoH_iEI2Q" value="_aTYA8I6KEeuY0umjNgUiVA"/>
  </node>
  <node defType="com.stambia.flow.step" id="8d590262-f985-3160-b65b-587b541181a6" name="I1_IND_SESSION_FILE_OP_HST">
    <attribute defType="com.stambia.flow.step.desc" id="_PmDjI5cQEeuuFLoH_iEI2Q"/>
    <attribute defType="com.stambia.flow.step.type" id="_PmH0kZcQEeuuFLoH_iEI2Q" value="Integration"/>
    <attribute defType="com.stambia.flow.step.target" id="_PmIboJcQEeuuFLoH_iEI2Q" value="$MD_0"/>
    <attribute defType="com.stambia.flow.step.srcProduct" id="_PmIboZcQEeuuFLoH_iEI2Q"/>
    <attribute defType="com.stambia.flow.step.trgProduct" id="_PmIbopcQEeuuFLoH_iEI2Q" value="MICROSOFT_SQL_SERVER"/>
    <attribute defType="com.stambia.flow.step.tplCriteria" id="_PmIbo5cQEeuuFLoH_iEI2Q" value="type=I-TP;trgProduct=MICROSOFT_SQL_SERVER;trgPath=server:SQL_FILEDB/schema:filecloudDB.USTB00/datastore:IND_SESSION_FILE_OP_HST;trgWorkspaceCapability=true;trgMapCapability=true;trgFilterCapability=true;trgJoinCapability=true;srcProductList=MICROSOFT_SQL_SERVER"/>
    <attribute defType="com.stambia.flow.step.number" id="_PmIbpJcQEeuuFLoH_iEI2Q" value="1"/>
    <node defType="com.stambia.flow.source" id="_PmK4AZcQEeuuFLoH_iEI2Q" name="STB_PARAM_NASAZ_FILE">
      <attribute defType="com.stambia.flow.source.target" id="_PmK4ApcQEeuuFLoH_iEI2Q" value="$MD_61"/>
    </node>
    <node defType="com.stambia.flow.filter" id="md__AdpNgHsMEeuX3smAOEfzKA">
      <attribute defType="com.stambia.flow.filter.tag" id="_PmK3-5cQEeuuFLoH_iEI2Q"/>
      <attribute defType="com.stambia.flow.filter.version" id="_PmK3_JcQEeuuFLoH_iEI2Q" value="2"/>
      <attribute defType="com.stambia.flow.filter.source" id="_PmK3_ZcQEeuuFLoH_iEI2Q">
        <values>$MD_60</values>
      </attribute>
      <attribute defType="com.stambia.flow.filter.sourceNames" id="_PmK3_pcQEeuuFLoH_iEI2Q">
        <values>STB_PARAM_NASAZ_FILE.%{MD_60}%</values>
      </attribute>
      <attribute defType="com.stambia.flow.filter.sourceContainer" id="_PmK3_5cQEeuuFLoH_iEI2Q">
        <values>STB_PARAM_NASAZ_FILE</values>
      </attribute>
      <attribute defType="com.stambia.flow.filter.expr" id="_PmK4AJcQEeuuFLoH_iEI2Q" value="'STB_PARAM_NASAZ_FILE.%{MD_60}% = ''En Proceso'''"/>
    </node>
    <node defType="com.stambia.flow.field" id="_PmIbpZcQEeuuFLoH_iEI2Q" name="SESS_ID">
      <attribute defType="com.stambia.flow.field.tag" id="_PmIbppcQEeuuFLoH_iEI2Q"/>
      <attribute defType="com.stambia.flow.field.workname" id="_PmIbp5cQEeuuFLoH_iEI2Q" value="SESS_ID"/>
      <attribute defType="com.stambia.flow.field.base" id="_PmIbqJcQEeuuFLoH_iEI2Q" value="$MD_1"/>
      <attribute defType="com.stambia.flow.field.target" id="_PmIbqZcQEeuuFLoH_iEI2Q" value="$MD_1"/>
      <attribute defType="com.stambia.flow.field.location" id="_PmIbqpcQEeuuFLoH_iEI2Q" value="SRC"/>
      <attribute defType="com.stambia.flow.field.version" id="_PmIbq5cQEeuuFLoH_iEI2Q" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_PmIbrJcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_PmIbrZcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.source" id="_PmIbrpcQEeuuFLoH_iEI2Q">
        <values>$MD_2</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_PmIbr5cQEeuuFLoH_iEI2Q">
        <values>STB_PARAM_NASAZ_FILE.%{MD_2}%</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_PmIbsJcQEeuuFLoH_iEI2Q">
        <values>STB_PARAM_NASAZ_FILE</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.expr" id="_PmIbsZcQEeuuFLoH_iEI2Q" value="'STB_PARAM_NASAZ_FILE.%{MD_2}%'"/>
    </node>
    <node defType="com.stambia.flow.field" id="_PmIbspcQEeuuFLoH_iEI2Q" name="SESS_NAME">
      <attribute defType="com.stambia.flow.field.tag" id="_PmIbs5cQEeuuFLoH_iEI2Q"/>
      <attribute defType="com.stambia.flow.field.workname" id="_PmIbtJcQEeuuFLoH_iEI2Q" value="SESS_NAME"/>
      <attribute defType="com.stambia.flow.field.base" id="_PmIbtZcQEeuuFLoH_iEI2Q" value="$MD_3"/>
      <attribute defType="com.stambia.flow.field.target" id="_PmIbtpcQEeuuFLoH_iEI2Q" value="$MD_3"/>
      <attribute defType="com.stambia.flow.field.location" id="_PmIbt5cQEeuuFLoH_iEI2Q" value="SRC"/>
      <attribute defType="com.stambia.flow.field.version" id="_PmIbuJcQEeuuFLoH_iEI2Q" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_PmIbuZcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_PmIbupcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.source" id="_PmIbu5cQEeuuFLoH_iEI2Q">
        <values>$MD_4</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_PmIbvJcQEeuuFLoH_iEI2Q">
        <values>STB_PARAM_NASAZ_FILE.%{MD_4}%</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_PmIbvZcQEeuuFLoH_iEI2Q">
        <values>STB_PARAM_NASAZ_FILE</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.expr" id="_PmIbvpcQEeuuFLoH_iEI2Q" value="'STB_PARAM_NASAZ_FILE.%{MD_4}%'"/>
    </node>
    <node defType="com.stambia.flow.field" id="_PmIbv5cQEeuuFLoH_iEI2Q" name="ACT_ID">
      <attribute defType="com.stambia.flow.field.tag" id="_PmIbwJcQEeuuFLoH_iEI2Q"/>
      <attribute defType="com.stambia.flow.field.workname" id="_PmIbwZcQEeuuFLoH_iEI2Q" value="ACT_ID"/>
      <attribute defType="com.stambia.flow.field.base" id="_PmIbwpcQEeuuFLoH_iEI2Q" value="$MD_5"/>
      <attribute defType="com.stambia.flow.field.target" id="_PmIbw5cQEeuuFLoH_iEI2Q" value="$MD_5"/>
      <attribute defType="com.stambia.flow.field.location" id="_PmIbxJcQEeuuFLoH_iEI2Q" value="SRC"/>
      <attribute defType="com.stambia.flow.field.version" id="_PmIbxZcQEeuuFLoH_iEI2Q" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_PmIbxpcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_PmIbx5cQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.source" id="_PmIbyJcQEeuuFLoH_iEI2Q">
        <values>$MD_6</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_PmIbyZcQEeuuFLoH_iEI2Q">
        <values>STB_PARAM_NASAZ_FILE.%{MD_6}%</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_PmIbypcQEeuuFLoH_iEI2Q">
        <values>STB_PARAM_NASAZ_FILE</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.expr" id="_PmIby5cQEeuuFLoH_iEI2Q" value="'STB_PARAM_NASAZ_FILE.%{MD_6}%'"/>
    </node>
    <node defType="com.stambia.flow.field" id="_PmIbzJcQEeuuFLoH_iEI2Q" name="ACT_NAME">
      <attribute defType="com.stambia.flow.field.tag" id="_PmIbzZcQEeuuFLoH_iEI2Q"/>
      <attribute defType="com.stambia.flow.field.workname" id="_PmIbzpcQEeuuFLoH_iEI2Q" value="ACT_NAME"/>
      <attribute defType="com.stambia.flow.field.base" id="_PmIbz5cQEeuuFLoH_iEI2Q" value="$MD_7"/>
      <attribute defType="com.stambia.flow.field.target" id="_PmIb0JcQEeuuFLoH_iEI2Q" value="$MD_7"/>
      <attribute defType="com.stambia.flow.field.location" id="_PmIb0ZcQEeuuFLoH_iEI2Q" value="SRC"/>
      <attribute defType="com.stambia.flow.field.version" id="_PmIb0pcQEeuuFLoH_iEI2Q" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_PmIb05cQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_PmIb1JcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.source" id="_PmIb1ZcQEeuuFLoH_iEI2Q">
        <values>$MD_8</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_PmIb1pcQEeuuFLoH_iEI2Q">
        <values>STB_PARAM_NASAZ_FILE.%{MD_8}%</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_PmIb15cQEeuuFLoH_iEI2Q">
        <values>STB_PARAM_NASAZ_FILE</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.expr" id="_PmIb2JcQEeuuFLoH_iEI2Q" value="'STB_PARAM_NASAZ_FILE.%{MD_8}%'"/>
    </node>
    <node defType="com.stambia.flow.field" id="_PmIb2ZcQEeuuFLoH_iEI2Q" name="ACT_ITER">
      <attribute defType="com.stambia.flow.field.tag" id="_PmIb2pcQEeuuFLoH_iEI2Q"/>
      <attribute defType="com.stambia.flow.field.workname" id="_PmIb25cQEeuuFLoH_iEI2Q" value="ACT_ITER"/>
      <attribute defType="com.stambia.flow.field.base" id="_PmIb3JcQEeuuFLoH_iEI2Q" value="$MD_9"/>
      <attribute defType="com.stambia.flow.field.target" id="_PmIb3ZcQEeuuFLoH_iEI2Q" value="$MD_9"/>
      <attribute defType="com.stambia.flow.field.location" id="_PmIb3pcQEeuuFLoH_iEI2Q" value="SRC"/>
      <attribute defType="com.stambia.flow.field.version" id="_PmIb35cQEeuuFLoH_iEI2Q" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_PmJCsJcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_PmJCsZcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.source" id="_PmJCspcQEeuuFLoH_iEI2Q">
        <values>$MD_10</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_PmJCs5cQEeuuFLoH_iEI2Q">
        <values>STB_PARAM_NASAZ_FILE.%{MD_10}%</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_PmJCtJcQEeuuFLoH_iEI2Q">
        <values>STB_PARAM_NASAZ_FILE</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.expr" id="_PmJCtZcQEeuuFLoH_iEI2Q" value="'STB_PARAM_NASAZ_FILE.%{MD_10}%'"/>
    </node>
    <node defType="com.stambia.flow.field" id="_PmJCtpcQEeuuFLoH_iEI2Q" name="FILE_ID">
      <attribute defType="com.stambia.flow.field.tag" id="_PmJCt5cQEeuuFLoH_iEI2Q"/>
      <attribute defType="com.stambia.flow.field.workname" id="_PmJCuJcQEeuuFLoH_iEI2Q" value="FILE_ID"/>
      <attribute defType="com.stambia.flow.field.base" id="_PmJCuZcQEeuuFLoH_iEI2Q" value="$MD_11"/>
      <attribute defType="com.stambia.flow.field.target" id="_PmJCupcQEeuuFLoH_iEI2Q" value="$MD_11"/>
      <attribute defType="com.stambia.flow.field.location" id="_PmJCu5cQEeuuFLoH_iEI2Q" value="SRC"/>
      <attribute defType="com.stambia.flow.field.version" id="_PmJCvJcQEeuuFLoH_iEI2Q" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_PmJCvZcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_PmJCvpcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.source" id="_PmJCv5cQEeuuFLoH_iEI2Q">
        <values>$MD_12</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_PmJCwJcQEeuuFLoH_iEI2Q">
        <values>STB_PARAM_NASAZ_FILE.%{MD_12}%</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_PmJCwZcQEeuuFLoH_iEI2Q">
        <values>STB_PARAM_NASAZ_FILE</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.expr" id="_PmJCwpcQEeuuFLoH_iEI2Q" value="'STB_PARAM_NASAZ_FILE.%{MD_12}%'"/>
    </node>
    <node defType="com.stambia.flow.field" id="_PmJCw5cQEeuuFLoH_iEI2Q" name="FILE_OPERATION">
      <attribute defType="com.stambia.flow.field.tag" id="_PmJCxJcQEeuuFLoH_iEI2Q"/>
      <attribute defType="com.stambia.flow.field.workname" id="_PmJCxZcQEeuuFLoH_iEI2Q" value="FILE_OPERATION"/>
      <attribute defType="com.stambia.flow.field.base" id="_PmJCxpcQEeuuFLoH_iEI2Q" value="$MD_13"/>
      <attribute defType="com.stambia.flow.field.target" id="_PmJCx5cQEeuuFLoH_iEI2Q" value="$MD_13"/>
      <attribute defType="com.stambia.flow.field.location" id="_PmJCyJcQEeuuFLoH_iEI2Q" value="SRC"/>
      <attribute defType="com.stambia.flow.field.version" id="_PmJCyZcQEeuuFLoH_iEI2Q" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_PmJCypcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_PmJCy5cQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.source" id="_PmJCzJcQEeuuFLoH_iEI2Q">
        <values>$MD_14</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_PmJCzZcQEeuuFLoH_iEI2Q">
        <values>STB_PARAM_NASAZ_FILE.%{MD_14}%</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_PmJCzpcQEeuuFLoH_iEI2Q">
        <values>STB_PARAM_NASAZ_FILE</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.expr" id="_PmJCz5cQEeuuFLoH_iEI2Q" value="'STB_PARAM_NASAZ_FILE.%{MD_14}%'"/>
    </node>
    <node defType="com.stambia.flow.field" id="_PmJC0JcQEeuuFLoH_iEI2Q" name="FILE_NAME">
      <attribute defType="com.stambia.flow.field.tag" id="_PmJC0ZcQEeuuFLoH_iEI2Q"/>
      <attribute defType="com.stambia.flow.field.workname" id="_PmJC0pcQEeuuFLoH_iEI2Q" value="FILE_NAME"/>
      <attribute defType="com.stambia.flow.field.base" id="_PmJC05cQEeuuFLoH_iEI2Q" value="$MD_15"/>
      <attribute defType="com.stambia.flow.field.target" id="_PmJC1JcQEeuuFLoH_iEI2Q" value="$MD_15"/>
      <attribute defType="com.stambia.flow.field.location" id="_PmJC1ZcQEeuuFLoH_iEI2Q" value="SRC"/>
      <attribute defType="com.stambia.flow.field.version" id="_PmJC1pcQEeuuFLoH_iEI2Q" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_PmJC15cQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_PmJC2JcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.updatekey" id="_PmJC2ZcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.source" id="_PmJC2pcQEeuuFLoH_iEI2Q">
        <values>$MD_16</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_PmJC25cQEeuuFLoH_iEI2Q">
        <values>STB_PARAM_NASAZ_FILE.%{MD_16}%</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_PmJC3JcQEeuuFLoH_iEI2Q">
        <values>STB_PARAM_NASAZ_FILE</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.expr" id="_PmJC3ZcQEeuuFLoH_iEI2Q" value="'STB_PARAM_NASAZ_FILE.%{MD_16}%'"/>
    </node>
    <node defType="com.stambia.flow.field" id="_PmJC3pcQEeuuFLoH_iEI2Q" name="FILE_DIR">
      <attribute defType="com.stambia.flow.field.tag" id="_PmJC35cQEeuuFLoH_iEI2Q"/>
      <attribute defType="com.stambia.flow.field.workname" id="_PmJC4JcQEeuuFLoH_iEI2Q" value="FILE_DIR"/>
      <attribute defType="com.stambia.flow.field.base" id="_PmJC4ZcQEeuuFLoH_iEI2Q" value="$MD_17"/>
      <attribute defType="com.stambia.flow.field.target" id="_PmJC4pcQEeuuFLoH_iEI2Q" value="$MD_17"/>
      <attribute defType="com.stambia.flow.field.location" id="_PmJC45cQEeuuFLoH_iEI2Q" value="SRC"/>
      <attribute defType="com.stambia.flow.field.version" id="_PmJC5JcQEeuuFLoH_iEI2Q" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_PmJC5ZcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_PmJC5pcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.updatekey" id="_PmJC55cQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.source" id="_PmJC6JcQEeuuFLoH_iEI2Q">
        <values>$MD_18</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_PmJC6ZcQEeuuFLoH_iEI2Q">
        <values>STB_PARAM_NASAZ_FILE.%{MD_18}%</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_PmJC6pcQEeuuFLoH_iEI2Q">
        <values>STB_PARAM_NASAZ_FILE</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.expr" id="_PmJC65cQEeuuFLoH_iEI2Q" value="'STB_PARAM_NASAZ_FILE.%{MD_18}%'"/>
    </node>
    <node defType="com.stambia.flow.field" id="_PmJC7JcQEeuuFLoH_iEI2Q" name="ESTADO">
      <attribute defType="com.stambia.flow.field.tag" id="_PmJC7ZcQEeuuFLoH_iEI2Q"/>
      <attribute defType="com.stambia.flow.field.workname" id="_PmJC7pcQEeuuFLoH_iEI2Q" value="ESTADO"/>
      <attribute defType="com.stambia.flow.field.base" id="_PmJC75cQEeuuFLoH_iEI2Q" value="$MD_19"/>
      <attribute defType="com.stambia.flow.field.target" id="_PmJC8JcQEeuuFLoH_iEI2Q" value="$MD_19"/>
      <attribute defType="com.stambia.flow.field.location" id="_PmJC8ZcQEeuuFLoH_iEI2Q" value="SRC"/>
      <attribute defType="com.stambia.flow.field.version" id="_PmJC8pcQEeuuFLoH_iEI2Q" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_PmJC85cQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_PmJC9JcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.expr" id="_PmJC9ZcQEeuuFLoH_iEI2Q" value="'''Hecho'''"/>
    </node>
    <node defType="com.stambia.flow.field" id="_PmJC9pcQEeuuFLoH_iEI2Q" name="RUTA_AZURE">
      <attribute defType="com.stambia.flow.field.tag" id="_PmJC95cQEeuuFLoH_iEI2Q"/>
      <attribute defType="com.stambia.flow.field.workname" id="_PmJC-JcQEeuuFLoH_iEI2Q" value="RUTA_AZURE"/>
      <attribute defType="com.stambia.flow.field.base" id="_PmJC-ZcQEeuuFLoH_iEI2Q" value="$MD_20"/>
      <attribute defType="com.stambia.flow.field.target" id="_PmJC-pcQEeuuFLoH_iEI2Q" value="$MD_20"/>
      <attribute defType="com.stambia.flow.field.location" id="_PmJC-5cQEeuuFLoH_iEI2Q" value="SRC"/>
      <attribute defType="com.stambia.flow.field.version" id="_PmJC_JcQEeuuFLoH_iEI2Q" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_PmJC_ZcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_PmJC_pcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.source" id="_PmJC_5cQEeuuFLoH_iEI2Q">
        <values>$MD_21</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_PmJDAJcQEeuuFLoH_iEI2Q">
        <values>STB_PARAM_NASAZ_FILE.%{MD_21}%</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_PmJDAZcQEeuuFLoH_iEI2Q">
        <values>STB_PARAM_NASAZ_FILE</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.expr" id="_PmJDApcQEeuuFLoH_iEI2Q" value="'STB_PARAM_NASAZ_FILE.%{MD_21}%'"/>
    </node>
    <node defType="com.stambia.flow.field" id="_PmJDA5cQEeuuFLoH_iEI2Q" name="FILE_LENGTH">
      <attribute defType="com.stambia.flow.field.tag" id="_PmJDBJcQEeuuFLoH_iEI2Q"/>
      <attribute defType="com.stambia.flow.field.workname" id="_PmJDBZcQEeuuFLoH_iEI2Q" value="FILE_LENGTH"/>
      <attribute defType="com.stambia.flow.field.base" id="_PmJDBpcQEeuuFLoH_iEI2Q" value="$MD_22"/>
      <attribute defType="com.stambia.flow.field.target" id="_PmJDB5cQEeuuFLoH_iEI2Q" value="$MD_22"/>
      <attribute defType="com.stambia.flow.field.location" id="_PmJDCJcQEeuuFLoH_iEI2Q" value="SRC"/>
      <attribute defType="com.stambia.flow.field.version" id="_PmJDCZcQEeuuFLoH_iEI2Q" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_PmJDCpcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_PmJDC5cQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.source" id="_PmJDDJcQEeuuFLoH_iEI2Q">
        <values>$MD_23</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_PmJDDZcQEeuuFLoH_iEI2Q">
        <values>STB_PARAM_NASAZ_FILE.%{MD_23}%</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_PmJDDpcQEeuuFLoH_iEI2Q">
        <values>STB_PARAM_NASAZ_FILE</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.expr" id="_PmJDD5cQEeuuFLoH_iEI2Q" value="'STB_PARAM_NASAZ_FILE.%{MD_23}%'"/>
    </node>
    <node defType="com.stambia.flow.field" id="_PmJDEJcQEeuuFLoH_iEI2Q" name="FILE_LAST_MODIFIED_DATE">
      <attribute defType="com.stambia.flow.field.tag" id="_PmJDEZcQEeuuFLoH_iEI2Q"/>
      <attribute defType="com.stambia.flow.field.workname" id="_PmJDEpcQEeuuFLoH_iEI2Q" value="FILE_LAST_MODIFIED_DATE"/>
      <attribute defType="com.stambia.flow.field.base" id="_PmJDE5cQEeuuFLoH_iEI2Q" value="$MD_24"/>
      <attribute defType="com.stambia.flow.field.target" id="_PmJDFJcQEeuuFLoH_iEI2Q" value="$MD_24"/>
      <attribute defType="com.stambia.flow.field.location" id="_PmJDFZcQEeuuFLoH_iEI2Q" value="SRC"/>
      <attribute defType="com.stambia.flow.field.version" id="_PmJDFpcQEeuuFLoH_iEI2Q" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_PmJDF5cQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_PmJDGJcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.source" id="_PmJDGZcQEeuuFLoH_iEI2Q">
        <values>$MD_25</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_PmJDGpcQEeuuFLoH_iEI2Q">
        <values>STB_PARAM_NASAZ_FILE.%{MD_25}%</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_PmJpwJcQEeuuFLoH_iEI2Q">
        <values>STB_PARAM_NASAZ_FILE</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.expr" id="_PmJpwZcQEeuuFLoH_iEI2Q" value="'STB_PARAM_NASAZ_FILE.%{MD_25}%'"/>
    </node>
    <node defType="com.stambia.flow.field" id="_PmJpwpcQEeuuFLoH_iEI2Q" name="FILE_TO_DIR">
      <attribute defType="com.stambia.flow.field.tag" id="_PmJpw5cQEeuuFLoH_iEI2Q"/>
      <attribute defType="com.stambia.flow.field.workname" id="_PmJpxJcQEeuuFLoH_iEI2Q" value="FILE_TO_DIR"/>
      <attribute defType="com.stambia.flow.field.base" id="_PmJpxZcQEeuuFLoH_iEI2Q" value="$MD_26"/>
      <attribute defType="com.stambia.flow.field.target" id="_PmJpxpcQEeuuFLoH_iEI2Q" value="$MD_26"/>
      <attribute defType="com.stambia.flow.field.location" id="_PmJpx5cQEeuuFLoH_iEI2Q" value="SRC"/>
      <attribute defType="com.stambia.flow.field.version" id="_PmJpyJcQEeuuFLoH_iEI2Q" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_PmJpyZcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_PmJpypcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.source" id="_PmJpy5cQEeuuFLoH_iEI2Q">
        <values>$MD_27</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_PmJpzJcQEeuuFLoH_iEI2Q">
        <values>STB_PARAM_NASAZ_FILE.%{MD_27}%</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_PmJpzZcQEeuuFLoH_iEI2Q">
        <values>STB_PARAM_NASAZ_FILE</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.expr" id="_PmJpzpcQEeuuFLoH_iEI2Q" value="'STB_PARAM_NASAZ_FILE.%{MD_27}%'"/>
    </node>
    <node defType="com.stambia.flow.field" id="_PmJpz5cQEeuuFLoH_iEI2Q" name="FILE_TO_FILE">
      <attribute defType="com.stambia.flow.field.tag" id="_PmJp0JcQEeuuFLoH_iEI2Q"/>
      <attribute defType="com.stambia.flow.field.workname" id="_PmJp0ZcQEeuuFLoH_iEI2Q" value="FILE_TO_FILE"/>
      <attribute defType="com.stambia.flow.field.base" id="_PmJp0pcQEeuuFLoH_iEI2Q" value="$MD_28"/>
      <attribute defType="com.stambia.flow.field.target" id="_PmJp05cQEeuuFLoH_iEI2Q" value="$MD_28"/>
      <attribute defType="com.stambia.flow.field.location" id="_PmJp1JcQEeuuFLoH_iEI2Q" value="SRC"/>
      <attribute defType="com.stambia.flow.field.version" id="_PmJp1ZcQEeuuFLoH_iEI2Q" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_PmJp1pcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_PmJp15cQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.source" id="_PmJp2JcQEeuuFLoH_iEI2Q">
        <values>$MD_29</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_PmJp2ZcQEeuuFLoH_iEI2Q">
        <values>STB_PARAM_NASAZ_FILE.%{MD_29}%</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_PmJp2pcQEeuuFLoH_iEI2Q">
        <values>STB_PARAM_NASAZ_FILE</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.expr" id="_PmJp25cQEeuuFLoH_iEI2Q" value="'STB_PARAM_NASAZ_FILE.%{MD_29}%'"/>
    </node>
    <node defType="com.stambia.flow.field" id="_PmJp3JcQEeuuFLoH_iEI2Q" name="FILE_OPERATION_DATE">
      <attribute defType="com.stambia.flow.field.tag" id="_PmJp3ZcQEeuuFLoH_iEI2Q"/>
      <attribute defType="com.stambia.flow.field.workname" id="_PmJp3pcQEeuuFLoH_iEI2Q" value="FILE_OPERATION_DATE"/>
      <attribute defType="com.stambia.flow.field.base" id="_PmJp35cQEeuuFLoH_iEI2Q" value="$MD_30"/>
      <attribute defType="com.stambia.flow.field.target" id="_PmJp4JcQEeuuFLoH_iEI2Q" value="$MD_30"/>
      <attribute defType="com.stambia.flow.field.location" id="_PmJp4ZcQEeuuFLoH_iEI2Q" value="SRC"/>
      <attribute defType="com.stambia.flow.field.version" id="_PmJp4pcQEeuuFLoH_iEI2Q" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_PmJp45cQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_PmJp5JcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.source" id="_PmJp5ZcQEeuuFLoH_iEI2Q">
        <values>$MD_31</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_PmJp5pcQEeuuFLoH_iEI2Q">
        <values>STB_PARAM_NASAZ_FILE.%{MD_31}%</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_PmJp55cQEeuuFLoH_iEI2Q">
        <values>STB_PARAM_NASAZ_FILE</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.expr" id="_PmJp6JcQEeuuFLoH_iEI2Q" value="'STB_PARAM_NASAZ_FILE.%{MD_31}%'"/>
    </node>
    <node defType="com.stambia.flow.field" id="_PmJp6ZcQEeuuFLoH_iEI2Q" name="STATUS">
      <attribute defType="com.stambia.flow.field.tag" id="_PmJp6pcQEeuuFLoH_iEI2Q"/>
      <attribute defType="com.stambia.flow.field.workname" id="_PmJp65cQEeuuFLoH_iEI2Q" value="STATUS"/>
      <attribute defType="com.stambia.flow.field.base" id="_PmJp7JcQEeuuFLoH_iEI2Q" value="$MD_32"/>
      <attribute defType="com.stambia.flow.field.target" id="_PmJp7ZcQEeuuFLoH_iEI2Q" value="$MD_32"/>
      <attribute defType="com.stambia.flow.field.location" id="_PmJp7pcQEeuuFLoH_iEI2Q" value="SRC"/>
      <attribute defType="com.stambia.flow.field.version" id="_PmJp75cQEeuuFLoH_iEI2Q" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_PmJp8JcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_PmJp8ZcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.source" id="_PmJp8pcQEeuuFLoH_iEI2Q">
        <values>$MD_33</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_PmJp85cQEeuuFLoH_iEI2Q">
        <values>STB_PARAM_NASAZ_FILE.%{MD_33}%</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_PmJp9JcQEeuuFLoH_iEI2Q">
        <values>STB_PARAM_NASAZ_FILE</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.expr" id="_PmJp9ZcQEeuuFLoH_iEI2Q" value="'STB_PARAM_NASAZ_FILE.%{MD_33}%'"/>
    </node>
    <node defType="com.stambia.flow.field" id="_PmJp9pcQEeuuFLoH_iEI2Q" name="STATUS_COMMENT">
      <attribute defType="com.stambia.flow.field.tag" id="_PmJp95cQEeuuFLoH_iEI2Q"/>
      <attribute defType="com.stambia.flow.field.workname" id="_PmJp-JcQEeuuFLoH_iEI2Q" value="STATUS_COMMENT"/>
      <attribute defType="com.stambia.flow.field.base" id="_PmJp-ZcQEeuuFLoH_iEI2Q" value="$MD_34"/>
      <attribute defType="com.stambia.flow.field.target" id="_PmJp-pcQEeuuFLoH_iEI2Q" value="$MD_34"/>
      <attribute defType="com.stambia.flow.field.location" id="_PmJp-5cQEeuuFLoH_iEI2Q" value="SRC"/>
      <attribute defType="com.stambia.flow.field.version" id="_PmJp_JcQEeuuFLoH_iEI2Q" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_PmJp_ZcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_PmJp_pcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.source" id="_PmJp_5cQEeuuFLoH_iEI2Q">
        <values>$MD_35</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_PmJqAJcQEeuuFLoH_iEI2Q">
        <values>STB_PARAM_NASAZ_FILE.%{MD_35}%</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_PmJqAZcQEeuuFLoH_iEI2Q">
        <values>STB_PARAM_NASAZ_FILE</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.expr" id="_PmJqApcQEeuuFLoH_iEI2Q" value="'STB_PARAM_NASAZ_FILE.%{MD_35}%'"/>
    </node>
    <node defType="com.stambia.flow.field" id="_PmJqA5cQEeuuFLoH_iEI2Q" name="STATUS_DATE">
      <attribute defType="com.stambia.flow.field.tag" id="_PmJqBJcQEeuuFLoH_iEI2Q"/>
      <attribute defType="com.stambia.flow.field.workname" id="_PmJqBZcQEeuuFLoH_iEI2Q" value="STATUS_DATE"/>
      <attribute defType="com.stambia.flow.field.base" id="_PmJqBpcQEeuuFLoH_iEI2Q" value="$MD_36"/>
      <attribute defType="com.stambia.flow.field.target" id="_PmJqB5cQEeuuFLoH_iEI2Q" value="$MD_36"/>
      <attribute defType="com.stambia.flow.field.location" id="_PmJqCJcQEeuuFLoH_iEI2Q" value="SRC"/>
      <attribute defType="com.stambia.flow.field.version" id="_PmJqCZcQEeuuFLoH_iEI2Q" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_PmJqCpcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_PmJqC5cQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.source" id="_PmJqDJcQEeuuFLoH_iEI2Q">
        <values>$MD_37</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_PmJqDZcQEeuuFLoH_iEI2Q">
        <values>STB_PARAM_NASAZ_FILE.%{MD_37}%</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_PmJqDpcQEeuuFLoH_iEI2Q">
        <values>STB_PARAM_NASAZ_FILE</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.expr" id="_PmJqD5cQEeuuFLoH_iEI2Q" value="'STB_PARAM_NASAZ_FILE.%{MD_37}%'"/>
    </node>
    <node defType="com.stambia.flow.field" id="_PmJqEJcQEeuuFLoH_iEI2Q" name="USER_COMMENT">
      <attribute defType="com.stambia.flow.field.tag" id="_PmJqEZcQEeuuFLoH_iEI2Q"/>
      <attribute defType="com.stambia.flow.field.workname" id="_PmJqEpcQEeuuFLoH_iEI2Q" value="USER_COMMENT"/>
      <attribute defType="com.stambia.flow.field.base" id="_PmJqE5cQEeuuFLoH_iEI2Q" value="$MD_38"/>
      <attribute defType="com.stambia.flow.field.target" id="_PmJqFJcQEeuuFLoH_iEI2Q" value="$MD_38"/>
      <attribute defType="com.stambia.flow.field.location" id="_PmJqFZcQEeuuFLoH_iEI2Q" value="SRC"/>
      <attribute defType="com.stambia.flow.field.version" id="_PmJqFpcQEeuuFLoH_iEI2Q" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_PmJqF5cQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_PmJqGJcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.source" id="_PmJqGZcQEeuuFLoH_iEI2Q">
        <values>$MD_39</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_PmJqGpcQEeuuFLoH_iEI2Q">
        <values>STB_PARAM_NASAZ_FILE.%{MD_39}%</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_PmJqG5cQEeuuFLoH_iEI2Q">
        <values>STB_PARAM_NASAZ_FILE</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.expr" id="_PmJqHJcQEeuuFLoH_iEI2Q" value="'STB_PARAM_NASAZ_FILE.%{MD_39}%'"/>
    </node>
    <node defType="com.stambia.flow.field" id="_PmJqHZcQEeuuFLoH_iEI2Q" name="USER_FLAG">
      <attribute defType="com.stambia.flow.field.tag" id="_PmJqHpcQEeuuFLoH_iEI2Q"/>
      <attribute defType="com.stambia.flow.field.workname" id="_PmJqH5cQEeuuFLoH_iEI2Q" value="USER_FLAG"/>
      <attribute defType="com.stambia.flow.field.base" id="_PmJqIJcQEeuuFLoH_iEI2Q" value="$MD_40"/>
      <attribute defType="com.stambia.flow.field.target" id="_PmJqIZcQEeuuFLoH_iEI2Q" value="$MD_40"/>
      <attribute defType="com.stambia.flow.field.location" id="_PmJqIpcQEeuuFLoH_iEI2Q" value="SRC"/>
      <attribute defType="com.stambia.flow.field.version" id="_PmJqI5cQEeuuFLoH_iEI2Q" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_PmJqJJcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_PmJqJZcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.source" id="_PmJqJpcQEeuuFLoH_iEI2Q">
        <values>$MD_41</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_PmJqJ5cQEeuuFLoH_iEI2Q">
        <values>STB_PARAM_NASAZ_FILE.%{MD_41}%</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_PmJqKJcQEeuuFLoH_iEI2Q">
        <values>STB_PARAM_NASAZ_FILE</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.expr" id="_PmJqKZcQEeuuFLoH_iEI2Q" value="'STB_PARAM_NASAZ_FILE.%{MD_41}%'"/>
    </node>
    <node defType="com.stambia.flow.field" id="_PmJqKpcQEeuuFLoH_iEI2Q" name="USER_DATE">
      <attribute defType="com.stambia.flow.field.tag" id="_PmJqK5cQEeuuFLoH_iEI2Q"/>
      <attribute defType="com.stambia.flow.field.workname" id="_PmJqLJcQEeuuFLoH_iEI2Q" value="USER_DATE"/>
      <attribute defType="com.stambia.flow.field.base" id="_PmJqLZcQEeuuFLoH_iEI2Q" value="$MD_42"/>
      <attribute defType="com.stambia.flow.field.target" id="_PmJqLpcQEeuuFLoH_iEI2Q" value="$MD_42"/>
      <attribute defType="com.stambia.flow.field.location" id="_PmJqL5cQEeuuFLoH_iEI2Q" value="SRC"/>
      <attribute defType="com.stambia.flow.field.version" id="_PmJqMJcQEeuuFLoH_iEI2Q" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_PmJqMZcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_PmKQ0JcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.source" id="_PmKQ0ZcQEeuuFLoH_iEI2Q">
        <values>$MD_43</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_PmKQ0pcQEeuuFLoH_iEI2Q">
        <values>STB_PARAM_NASAZ_FILE.%{MD_43}%</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_PmKQ05cQEeuuFLoH_iEI2Q">
        <values>STB_PARAM_NASAZ_FILE</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.expr" id="_PmKQ1JcQEeuuFLoH_iEI2Q" value="'STB_PARAM_NASAZ_FILE.%{MD_43}%'"/>
    </node>
    <node defType="com.stambia.flow.field" id="_PmKQ1ZcQEeuuFLoH_iEI2Q" name="FILE_IS_HIDDEN">
      <attribute defType="com.stambia.flow.field.tag" id="_PmKQ1pcQEeuuFLoH_iEI2Q"/>
      <attribute defType="com.stambia.flow.field.workname" id="_PmKQ15cQEeuuFLoH_iEI2Q" value="FILE_IS_HIDDEN"/>
      <attribute defType="com.stambia.flow.field.base" id="_PmKQ2JcQEeuuFLoH_iEI2Q" value="$MD_44"/>
      <attribute defType="com.stambia.flow.field.target" id="_PmKQ2ZcQEeuuFLoH_iEI2Q" value="$MD_44"/>
      <attribute defType="com.stambia.flow.field.location" id="_PmKQ2pcQEeuuFLoH_iEI2Q" value="SRC"/>
      <attribute defType="com.stambia.flow.field.version" id="_PmKQ25cQEeuuFLoH_iEI2Q" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_PmKQ3JcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_PmKQ3ZcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.source" id="_PmKQ3pcQEeuuFLoH_iEI2Q">
        <values>$MD_45</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_PmKQ35cQEeuuFLoH_iEI2Q">
        <values>STB_PARAM_NASAZ_FILE.%{MD_45}%</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_PmKQ4JcQEeuuFLoH_iEI2Q">
        <values>STB_PARAM_NASAZ_FILE</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.expr" id="_PmKQ4ZcQEeuuFLoH_iEI2Q" value="'STB_PARAM_NASAZ_FILE.%{MD_45}%'"/>
    </node>
    <node defType="com.stambia.flow.field" id="_PmKQ4pcQEeuuFLoH_iEI2Q" name="FILE_LAST_MODIFIED">
      <attribute defType="com.stambia.flow.field.tag" id="_PmKQ45cQEeuuFLoH_iEI2Q"/>
      <attribute defType="com.stambia.flow.field.workname" id="_PmKQ5JcQEeuuFLoH_iEI2Q" value="FILE_LAST_MODIFIED"/>
      <attribute defType="com.stambia.flow.field.base" id="_PmKQ5ZcQEeuuFLoH_iEI2Q" value="$MD_46"/>
      <attribute defType="com.stambia.flow.field.target" id="_PmKQ5pcQEeuuFLoH_iEI2Q" value="$MD_46"/>
      <attribute defType="com.stambia.flow.field.location" id="_PmKQ55cQEeuuFLoH_iEI2Q" value="SRC"/>
      <attribute defType="com.stambia.flow.field.version" id="_PmKQ6JcQEeuuFLoH_iEI2Q" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_PmKQ6ZcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_PmKQ6pcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.source" id="_PmKQ65cQEeuuFLoH_iEI2Q">
        <values>$MD_47</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_PmKQ7JcQEeuuFLoH_iEI2Q">
        <values>STB_PARAM_NASAZ_FILE.%{MD_47}%</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_PmKQ7ZcQEeuuFLoH_iEI2Q">
        <values>STB_PARAM_NASAZ_FILE</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.expr" id="_PmKQ7pcQEeuuFLoH_iEI2Q" value="'STB_PARAM_NASAZ_FILE.%{MD_47}%'"/>
    </node>
    <node defType="com.stambia.flow.field" id="_PmKQ75cQEeuuFLoH_iEI2Q" name="FILE_CAN_READ">
      <attribute defType="com.stambia.flow.field.tag" id="_PmKQ8JcQEeuuFLoH_iEI2Q"/>
      <attribute defType="com.stambia.flow.field.workname" id="_PmKQ8ZcQEeuuFLoH_iEI2Q" value="FILE_CAN_READ"/>
      <attribute defType="com.stambia.flow.field.base" id="_PmKQ8pcQEeuuFLoH_iEI2Q" value="$MD_48"/>
      <attribute defType="com.stambia.flow.field.target" id="_PmKQ85cQEeuuFLoH_iEI2Q" value="$MD_48"/>
      <attribute defType="com.stambia.flow.field.location" id="_PmKQ9JcQEeuuFLoH_iEI2Q" value="SRC"/>
      <attribute defType="com.stambia.flow.field.version" id="_PmKQ9ZcQEeuuFLoH_iEI2Q" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_PmKQ9pcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_PmKQ95cQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.source" id="_PmKQ-JcQEeuuFLoH_iEI2Q">
        <values>$MD_49</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_PmKQ-ZcQEeuuFLoH_iEI2Q">
        <values>STB_PARAM_NASAZ_FILE.%{MD_49}%</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_PmKQ-pcQEeuuFLoH_iEI2Q">
        <values>STB_PARAM_NASAZ_FILE</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.expr" id="_PmKQ-5cQEeuuFLoH_iEI2Q" value="'STB_PARAM_NASAZ_FILE.%{MD_49}%'"/>
    </node>
    <node defType="com.stambia.flow.field" id="_PmKQ_JcQEeuuFLoH_iEI2Q" name="FILE_CAN_WRITE">
      <attribute defType="com.stambia.flow.field.tag" id="_PmKQ_ZcQEeuuFLoH_iEI2Q"/>
      <attribute defType="com.stambia.flow.field.workname" id="_PmKQ_pcQEeuuFLoH_iEI2Q" value="FILE_CAN_WRITE"/>
      <attribute defType="com.stambia.flow.field.base" id="_PmKQ_5cQEeuuFLoH_iEI2Q" value="$MD_50"/>
      <attribute defType="com.stambia.flow.field.target" id="_PmKRAJcQEeuuFLoH_iEI2Q" value="$MD_50"/>
      <attribute defType="com.stambia.flow.field.location" id="_PmKRAZcQEeuuFLoH_iEI2Q" value="SRC"/>
      <attribute defType="com.stambia.flow.field.version" id="_PmKRApcQEeuuFLoH_iEI2Q" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_PmKRA5cQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_PmKRBJcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.source" id="_PmKRBZcQEeuuFLoH_iEI2Q">
        <values>$MD_51</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_PmKRBpcQEeuuFLoH_iEI2Q">
        <values>STB_PARAM_NASAZ_FILE.%{MD_51}%</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_PmKRB5cQEeuuFLoH_iEI2Q">
        <values>STB_PARAM_NASAZ_FILE</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.expr" id="_PmKRCJcQEeuuFLoH_iEI2Q" value="'STB_PARAM_NASAZ_FILE.%{MD_51}%'"/>
    </node>
    <node defType="com.stambia.flow.field" id="_PmKRCZcQEeuuFLoH_iEI2Q" name="FILE_CAN_EXECUTE">
      <attribute defType="com.stambia.flow.field.tag" id="_PmKRCpcQEeuuFLoH_iEI2Q"/>
      <attribute defType="com.stambia.flow.field.workname" id="_PmKRC5cQEeuuFLoH_iEI2Q" value="FILE_CAN_EXECUTE"/>
      <attribute defType="com.stambia.flow.field.base" id="_PmKRDJcQEeuuFLoH_iEI2Q" value="$MD_52"/>
      <attribute defType="com.stambia.flow.field.target" id="_PmKRDZcQEeuuFLoH_iEI2Q" value="$MD_52"/>
      <attribute defType="com.stambia.flow.field.location" id="_PmKRDpcQEeuuFLoH_iEI2Q" value="SRC"/>
      <attribute defType="com.stambia.flow.field.version" id="_PmKRD5cQEeuuFLoH_iEI2Q" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_PmKREJcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_PmKREZcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.source" id="_PmKREpcQEeuuFLoH_iEI2Q">
        <values>$MD_53</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_PmKRE5cQEeuuFLoH_iEI2Q">
        <values>STB_PARAM_NASAZ_FILE.%{MD_53}%</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_PmKRFJcQEeuuFLoH_iEI2Q">
        <values>STB_PARAM_NASAZ_FILE</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.expr" id="_PmKRFZcQEeuuFLoH_iEI2Q" value="'STB_PARAM_NASAZ_FILE.%{MD_53}%'"/>
    </node>
    <node defType="com.stambia.flow.field" id="_PmKRFpcQEeuuFLoH_iEI2Q" name="FILE_IS_DIRECTORY">
      <attribute defType="com.stambia.flow.field.tag" id="_PmKRF5cQEeuuFLoH_iEI2Q"/>
      <attribute defType="com.stambia.flow.field.workname" id="_PmKRGJcQEeuuFLoH_iEI2Q" value="FILE_IS_DIRECTORY"/>
      <attribute defType="com.stambia.flow.field.base" id="_PmKRGZcQEeuuFLoH_iEI2Q" value="$MD_54"/>
      <attribute defType="com.stambia.flow.field.target" id="_PmKRGpcQEeuuFLoH_iEI2Q" value="$MD_54"/>
      <attribute defType="com.stambia.flow.field.location" id="_PmKRG5cQEeuuFLoH_iEI2Q" value="SRC"/>
      <attribute defType="com.stambia.flow.field.version" id="_PmKRHJcQEeuuFLoH_iEI2Q" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_PmKRHZcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_PmKRHpcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.source" id="_PmKRH5cQEeuuFLoH_iEI2Q">
        <values>$MD_55</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_PmKRIJcQEeuuFLoH_iEI2Q">
        <values>STB_PARAM_NASAZ_FILE.%{MD_55}%</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_PmKRIZcQEeuuFLoH_iEI2Q">
        <values>STB_PARAM_NASAZ_FILE</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.expr" id="_PmKRIpcQEeuuFLoH_iEI2Q" value="'STB_PARAM_NASAZ_FILE.%{MD_55}%'"/>
    </node>
    <node defType="com.stambia.flow.field" id="_PmK34JcQEeuuFLoH_iEI2Q" name="FILE_FROM_DIR">
      <attribute defType="com.stambia.flow.field.tag" id="_PmK34ZcQEeuuFLoH_iEI2Q"/>
      <attribute defType="com.stambia.flow.field.workname" id="_PmK34pcQEeuuFLoH_iEI2Q" value="FILE_FROM_DIR"/>
      <attribute defType="com.stambia.flow.field.base" id="_PmK345cQEeuuFLoH_iEI2Q" value="$MD_56"/>
      <attribute defType="com.stambia.flow.field.target" id="_PmK35JcQEeuuFLoH_iEI2Q" value="$MD_56"/>
      <attribute defType="com.stambia.flow.field.location" id="_PmK35ZcQEeuuFLoH_iEI2Q" value="SRC"/>
      <attribute defType="com.stambia.flow.field.version" id="_PmK35pcQEeuuFLoH_iEI2Q" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_PmK355cQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_PmK36JcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.source" id="_PmK36ZcQEeuuFLoH_iEI2Q">
        <values>$MD_57</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_PmK36pcQEeuuFLoH_iEI2Q">
        <values>STB_PARAM_NASAZ_FILE.%{MD_57}%</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_PmK365cQEeuuFLoH_iEI2Q">
        <values>STB_PARAM_NASAZ_FILE</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.expr" id="_PmK37JcQEeuuFLoH_iEI2Q" value="'STB_PARAM_NASAZ_FILE.%{MD_57}%'"/>
    </node>
    <node defType="com.stambia.flow.field" id="_PmK37ZcQEeuuFLoH_iEI2Q" name="FILE_FROM_FILE">
      <attribute defType="com.stambia.flow.field.tag" id="_PmK37pcQEeuuFLoH_iEI2Q"/>
      <attribute defType="com.stambia.flow.field.workname" id="_PmK375cQEeuuFLoH_iEI2Q" value="FILE_FROM_FILE"/>
      <attribute defType="com.stambia.flow.field.base" id="_PmK38JcQEeuuFLoH_iEI2Q" value="$MD_58"/>
      <attribute defType="com.stambia.flow.field.target" id="_PmK38ZcQEeuuFLoH_iEI2Q" value="$MD_58"/>
      <attribute defType="com.stambia.flow.field.location" id="_PmK38pcQEeuuFLoH_iEI2Q" value="SRC"/>
      <attribute defType="com.stambia.flow.field.version" id="_PmK385cQEeuuFLoH_iEI2Q" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_PmK39JcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_PmK39ZcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.source" id="_PmK39pcQEeuuFLoH_iEI2Q">
        <values>$MD_59</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_PmK395cQEeuuFLoH_iEI2Q">
        <values>STB_PARAM_NASAZ_FILE.%{MD_59}%</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_PmK3-JcQEeuuFLoH_iEI2Q">
        <values>STB_PARAM_NASAZ_FILE</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.expr" id="_PmK3-ZcQEeuuFLoH_iEI2Q" value="'STB_PARAM_NASAZ_FILE.%{MD_59}%'"/>
    </node>
  </node>
  <metaDataLink name="MD_0" target="../../Metadata/SQL_FILEDB.md#_dqXRgZBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=IND_SESSION_FILE_OP_HST?"/>
  <metaDataLink name="MD_1" target="../../Metadata/SQL_FILEDB.md#_dqjewJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=SESS_ID?"/>
  <metaDataLink name="MD_2" target="../../Metadata/SQL_FILEDB.md#_dpP3MJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=SESS_ID?"/>
  <metaDataLink name="MD_3" target="../../Metadata/SQL_FILEDB.md#_dql7AJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=SESS_NAME?"/>
  <metaDataLink name="MD_4" target="../../Metadata/SQL_FILEDB.md#_dpRsYJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=SESS_NAME?"/>
  <metaDataLink name="MD_5" target="../../Metadata/SQL_FILEDB.md#_dqplYJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=ACT_ID?"/>
  <metaDataLink name="MD_6" target="../../Metadata/SQL_FILEDB.md#_dpThkJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=ACT_ID?"/>
  <metaDataLink name="MD_7" target="../../Metadata/SQL_FILEDB.md#_dqtPwJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=ACT_NAME?"/>
  <metaDataLink name="MD_8" target="../../Metadata/SQL_FILEDB.md#_dpVWwJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=ACT_NAME?"/>
  <metaDataLink name="MD_9" target="../../Metadata/SQL_FILEDB.md#_dqyIQJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=ACT_ITER?"/>
  <metaDataLink name="MD_10" target="../../Metadata/SQL_FILEDB.md#_dpXL8JBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=ACT_ITER?"/>
  <metaDataLink name="MD_11" target="../../Metadata/SQL_FILEDB.md#_dq0kgJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=FILE_ID?"/>
  <metaDataLink name="MD_12" target="../../Metadata/SQL_FILEDB.md#_dpZBIJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=FILE_ID?"/>
  <metaDataLink name="MD_13" target="../../Metadata/SQL_FILEDB.md#_dq3AwJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=FILE_OPERATION?"/>
  <metaDataLink name="MD_14" target="../../Metadata/SQL_FILEDB.md#_dpa2UJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=FILE_OPERATION?"/>
  <metaDataLink name="MD_15" target="../../Metadata/SQL_FILEDB.md#_dq6EEJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=FILE_NAME?"/>
  <metaDataLink name="MD_16" target="../../Metadata/SQL_FILEDB.md#_dpcEcJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=FILE_NAME?"/>
  <metaDataLink name="MD_17" target="../../Metadata/SQL_FILEDB.md#_dq9HYJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=FILE_DIR?"/>
  <metaDataLink name="MD_18" target="../../Metadata/SQL_FILEDB.md#_dpegsJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=FILE_DIR?"/>
  <metaDataLink name="MD_19" target="../../Metadata/SQL_FILEDB.md#_drB_4JBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=ESTADO?"/>
  <metaDataLink name="MD_20" target="../../Metadata/SQL_FILEDB.md#_drFqQJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=RUTA_AZURE?"/>
  <metaDataLink name="MD_21" target="../../Metadata/SQL_FILEDB.md#_dphkAJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=RUTA_AZURE?"/>
  <metaDataLink name="MD_22" target="../../Metadata/SQL_FILEDB.md#_drMX8JBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=FILE_LENGTH?"/>
  <metaDataLink name="MD_23" target="../../Metadata/SQL_FILEDB.md#_dpjZMJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=FILE_LENGTH?"/>
  <metaDataLink name="MD_24" target="../../Metadata/SQL_FILEDB.md#_drTFoJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=FILE_LAST_MODIFIED_DATE?"/>
  <metaDataLink name="MD_25" target="../../Metadata/SQL_FILEDB.md#_dplOYJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=FILE_LAST_MODIFIED_DATE?"/>
  <metaDataLink name="MD_26" target="../../Metadata/SQL_FILEDB.md#_draaYJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=FILE_TO_DIR?"/>
  <metaDataLink name="MD_27" target="../../Metadata/SQL_FILEDB.md#_dpmcgJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=FILE_TO_DIR?"/>
  <metaDataLink name="MD_28" target="../../Metadata/SQL_FILEDB.md#_dreEwJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=FILE_TO_FILE?"/>
  <metaDataLink name="MD_29" target="../../Metadata/SQL_FILEDB.md#_dpoRsJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=FILE_TO_FILE?"/>
  <metaDataLink name="MD_30" target="../../Metadata/SQL_FILEDB.md#_drhIEJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=FILE_OPERATION_DATE?"/>
  <metaDataLink name="MD_31" target="../../Metadata/SQL_FILEDB.md#_dpqG4JBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=FILE_OPERATION_DATE?"/>
  <metaDataLink name="MD_32" target="../../Metadata/SQL_FILEDB.md#_drsHMJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=STATUS?"/>
  <metaDataLink name="MD_33" target="../../Metadata/SQL_FILEDB.md#_dpr8EJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=STATUS?"/>
  <metaDataLink name="MD_34" target="../../Metadata/SQL_FILEDB.md#_dr_CIJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=STATUS_COMMENT?"/>
  <metaDataLink name="MD_35" target="../../Metadata/SQL_FILEDB.md#_dptxQJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=STATUS_COMMENT?"/>
  <metaDataLink name="MD_36" target="../../Metadata/SQL_FILEDB.md#_dsDTkJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=STATUS_DATE?"/>
  <metaDataLink name="MD_37" target="../../Metadata/SQL_FILEDB.md#_dpvmcJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=STATUS_DATE?"/>
  <metaDataLink name="MD_38" target="../../Metadata/SQL_FILEDB.md#_dsHlAJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=USER_COMMENT?"/>
  <metaDataLink name="MD_39" target="../../Metadata/SQL_FILEDB.md#_dpw0kJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=USER_COMMENT?"/>
  <metaDataLink name="MD_40" target="../../Metadata/SQL_FILEDB.md#_dsO5wJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=USER_FLAG?"/>
  <metaDataLink name="MD_41" target="../../Metadata/SQL_FILEDB.md#_dpypwJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=USER_FLAG?"/>
  <metaDataLink name="MD_42" target="../../Metadata/SQL_FILEDB.md#_dsUZUJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=USER_DATE?"/>
  <metaDataLink name="MD_43" target="../../Metadata/SQL_FILEDB.md#_dpz34JBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=USER_DATE?"/>
  <metaDataLink name="MD_44" target="../../Metadata/SQL_FILEDB.md#_dsYDsJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=FILE_IS_HIDDEN?"/>
  <metaDataLink name="MD_45" target="../../Metadata/SQL_FILEDB.md#_dp1tEJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=FILE_IS_HIDDEN?"/>
  <metaDataLink name="MD_46" target="../../Metadata/SQL_FILEDB.md#_dscVIJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=FILE_LAST_MODIFIED?"/>
  <metaDataLink name="MD_47" target="../../Metadata/SQL_FILEDB.md#_dp3iQJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=FILE_LAST_MODIFIED?"/>
  <metaDataLink name="MD_48" target="../../Metadata/SQL_FILEDB.md#_dsexYJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=FILE_CAN_READ?"/>
  <metaDataLink name="MD_49" target="../../Metadata/SQL_FILEDB.md#_dp4wYJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=FILE_CAN_READ?"/>
  <metaDataLink name="MD_50" target="../../Metadata/SQL_FILEDB.md#_dsgmkJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=FILE_CAN_WRITE?"/>
  <metaDataLink name="MD_51" target="../../Metadata/SQL_FILEDB.md#_dp6lkJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=FILE_CAN_WRITE?"/>
  <metaDataLink name="MD_52" target="../../Metadata/SQL_FILEDB.md#_dsk4AJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=FILE_CAN_EXECUTE?"/>
  <metaDataLink name="MD_53" target="../../Metadata/SQL_FILEDB.md#_dp8awJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=FILE_CAN_EXECUTE?"/>
  <metaDataLink name="MD_54" target="../../Metadata/SQL_FILEDB.md#_dsmtMJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=FILE_IS_DIRECTORY?"/>
  <metaDataLink name="MD_55" target="../../Metadata/SQL_FILEDB.md#_dp-P8JBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=FILE_IS_DIRECTORY?"/>
  <metaDataLink name="MD_56" target="../../Metadata/SQL_FILEDB.md#_dsoiYJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=FILE_FROM_DIR?"/>
  <metaDataLink name="MD_57" target="../../Metadata/SQL_FILEDB.md#_dqPVsJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=FILE_FROM_DIR?"/>
  <metaDataLink name="MD_58" target="../../Metadata/SQL_FILEDB.md#_dspwgJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=FILE_FROM_FILE?"/>
  <metaDataLink name="MD_59" target="../../Metadata/SQL_FILEDB.md#_dqRK4JBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=FILE_FROM_FILE?"/>
  <metaDataLink name="MD_60" target="../../Metadata/SQL_FILEDB.md#_dpfu0JBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=ESTADO?"/>
  <metaDataLink name="MD_61" target="../../Metadata/SQL_FILEDB.md#_dpGGMZBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=STB_PARAM_NASAZ_FILE?"/>
</md:node>