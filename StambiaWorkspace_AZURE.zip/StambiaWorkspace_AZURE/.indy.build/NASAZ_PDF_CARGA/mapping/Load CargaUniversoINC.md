<?xml version="1.0" encoding="UTF-8"?>
<md:node xmlns:md="http://www.stambia.com/md" defType="com.stambia.flow" id="_gdFLwJCbEeuNkLbBPIrucw-flow" name="Load CargaUniversoINC" md:ref="file:/C:/Users/D6855693/Documents/StambiaWorkspace_AZURE/.metadata/.plugins/com.indy.emf.uri/internalResource/technology/map/map.tech#_waYSMH8VEd2__Mzb_dB76A?fileId=_waYSMH8VEd2__Mzb_dB76A$type=tech$name=flow?">
  <node defType="com.stambia.flow.altId" id="_PnFd4ZcQEeuuFLoH_iEI2Q">
    <attribute defType="com.stambia.flow.altId.origin" id="_PnFd4pcQEeuuFLoH_iEI2Q" value="mapping"/>
    <attribute defType="com.stambia.flow.altId.value" id="_PnFd45cQEeuuFLoH_iEI2Q" value="_gdFLwJCbEeuNkLbBPIrucw"/>
  </node>
  <node defType="com.stambia.flow.step" id="cd9e8c88-22d2-37ab-b08b-459c8d422cd3" name="I1_STB_PARAM_NASAZ_FILE">
    <attribute defType="com.stambia.flow.step.desc" id="_PnIhMZcQEeuuFLoH_iEI2Q"/>
    <attribute defType="com.stambia.flow.step.type" id="_PnMLkZcQEeuuFLoH_iEI2Q" value="Integration"/>
    <attribute defType="com.stambia.flow.step.target" id="_PnMLkpcQEeuuFLoH_iEI2Q" value="$MD_0"/>
    <attribute defType="com.stambia.flow.step.srcProduct" id="_PnMLk5cQEeuuFLoH_iEI2Q"/>
    <attribute defType="com.stambia.flow.step.trgProduct" id="_PnMLlJcQEeuuFLoH_iEI2Q" value="MICROSOFT_SQL_SERVER"/>
    <attribute defType="com.stambia.flow.step.tplCriteria" id="_PnMLlZcQEeuuFLoH_iEI2Q" value="type=I-TP;trgProduct=MICROSOFT_SQL_SERVER;trgPath=server:SQL_FILEDB/schema:filecloudDB.USTB00/datastore:STB_PARAM_NASAZ_FILE;trgWorkspaceCapability=true;trgMapCapability=true;trgFilterCapability=true;trgJoinCapability=true;srcProductList=MICROSOFT_SQL_SERVER"/>
    <attribute defType="com.stambia.flow.step.number" id="_PnMLlpcQEeuuFLoH_iEI2Q" value="1"/>
    <node defType="com.stambia.flow.source" id="_PnPO45cQEeuuFLoH_iEI2Q" name="IND_SESSION_FILE_OP_TMP">
      <attribute defType="com.stambia.flow.source.target" id="_PnPO5JcQEeuuFLoH_iEI2Q" value="$MD_70"/>
    </node>
    <node defType="com.stambia.flow.source" id="_PnPO5ZcQEeuuFLoH_iEI2Q" name="STB_PARAM_NASAZURE">
      <attribute defType="com.stambia.flow.source.target" id="_PnPO5pcQEeuuFLoH_iEI2Q" value="$MD_71"/>
    </node>
    <node defType="com.stambia.flow.join" id="md__V9pYoJDAEeuNkLbBPIrucw">
      <attribute defType="com.stambia.flow.join.left" id="_PnOoL5cQEeuuFLoH_iEI2Q" value="IND_SESSION_FILE_OP_TMP"/>
      <attribute defType="com.stambia.flow.join.right" id="_PnOoMJcQEeuuFLoH_iEI2Q" value="STB_PARAM_NASAZURE"/>
      <attribute defType="com.stambia.flow.join.order" id="_PnOoMZcQEeuuFLoH_iEI2Q" value="10"/>
      <attribute defType="com.stambia.flow.join.type" id="_PnOoMpcQEeuuFLoH_iEI2Q" value="Inner_Join"/>
      <attribute defType="com.stambia.flow.join.tag" id="_PnOoM5cQEeuuFLoH_iEI2Q"/>
      <attribute defType="com.stambia.flow.join.version" id="_PnOoNJcQEeuuFLoH_iEI2Q" value="2"/>
      <attribute defType="com.stambia.flow.join.source" id="_PnOoNZcQEeuuFLoH_iEI2Q">
        <values>$MD_18</values>
        <values>$MD_23</values>
        <values>$MD_16</values>
      </attribute>
      <attribute defType="com.stambia.flow.join.sourceNames" id="_PnPO4JcQEeuuFLoH_iEI2Q">
        <values>STB_PARAM_NASAZURE.%{MD_23}%</values>
        <values>IND_SESSION_FILE_OP_TMP.%{MD_18}%</values>
        <values>IND_SESSION_FILE_OP_TMP.%{MD_16}%</values>
      </attribute>
      <attribute defType="com.stambia.flow.join.sourceContainer" id="_PnPO4ZcQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_TMP</values>
        <values>STB_PARAM_NASAZURE</values>
      </attribute>
      <attribute defType="com.stambia.flow.join.expr" id="_PnPO4pcQEeuuFLoH_iEI2Q" value="'STB_PARAM_NASAZURE.%{MD_23}% = SUBSTRING(IND_SESSION_FILE_OP_TMP.%{MD_18}%,1,LEN(STB_PARAM_NASAZURE.%{MD_23}%))&#xA;and UPPER(RIGHT(IND_SESSION_FILE_OP_TMP.%{MD_16}%,3)) = ''PDF''&#xA;&#xA;'"/>
    </node>
    <node defType="com.stambia.flow.field" id="_PnMyoJcQEeuuFLoH_iEI2Q" name="SESS_ID">
      <attribute defType="com.stambia.flow.field.tag" id="_PnMyoZcQEeuuFLoH_iEI2Q"/>
      <attribute defType="com.stambia.flow.field.workname" id="_PnMyopcQEeuuFLoH_iEI2Q" value="SESS_ID"/>
      <attribute defType="com.stambia.flow.field.base" id="_PnMyo5cQEeuuFLoH_iEI2Q" value="$MD_1"/>
      <attribute defType="com.stambia.flow.field.target" id="_PnMypJcQEeuuFLoH_iEI2Q" value="$MD_1"/>
      <attribute defType="com.stambia.flow.field.location" id="_PnMypZcQEeuuFLoH_iEI2Q" value="SRC"/>
      <attribute defType="com.stambia.flow.field.version" id="_PnMyppcQEeuuFLoH_iEI2Q" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_PnMyp5cQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_PnMyqJcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.source" id="_PnMyqZcQEeuuFLoH_iEI2Q">
        <values>$MD_2</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_PnMyqpcQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_TMP.%{MD_2}%</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_PnMyq5cQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_TMP</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.expr" id="_PnMyrJcQEeuuFLoH_iEI2Q" value="'IND_SESSION_FILE_OP_TMP.%{MD_2}%'"/>
    </node>
    <node defType="com.stambia.flow.field" id="_PnMyrZcQEeuuFLoH_iEI2Q" name="SESS_NAME">
      <attribute defType="com.stambia.flow.field.tag" id="_PnMyrpcQEeuuFLoH_iEI2Q"/>
      <attribute defType="com.stambia.flow.field.workname" id="_PnMyr5cQEeuuFLoH_iEI2Q" value="SESS_NAME"/>
      <attribute defType="com.stambia.flow.field.base" id="_PnMysJcQEeuuFLoH_iEI2Q" value="$MD_3"/>
      <attribute defType="com.stambia.flow.field.target" id="_PnMysZcQEeuuFLoH_iEI2Q" value="$MD_3"/>
      <attribute defType="com.stambia.flow.field.location" id="_PnMyspcQEeuuFLoH_iEI2Q" value="SRC"/>
      <attribute defType="com.stambia.flow.field.version" id="_PnMys5cQEeuuFLoH_iEI2Q" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_PnMytJcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_PnMytZcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.source" id="_PnMytpcQEeuuFLoH_iEI2Q">
        <values>$MD_4</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_PnMyt5cQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_TMP.%{MD_4}%</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_PnMyuJcQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_TMP</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.expr" id="_PnMyuZcQEeuuFLoH_iEI2Q" value="'IND_SESSION_FILE_OP_TMP.%{MD_4}%'"/>
    </node>
    <node defType="com.stambia.flow.field" id="_PnMyupcQEeuuFLoH_iEI2Q" name="ACT_ID">
      <attribute defType="com.stambia.flow.field.tag" id="_PnMyu5cQEeuuFLoH_iEI2Q"/>
      <attribute defType="com.stambia.flow.field.workname" id="_PnMyvJcQEeuuFLoH_iEI2Q" value="ACT_ID"/>
      <attribute defType="com.stambia.flow.field.base" id="_PnMyvZcQEeuuFLoH_iEI2Q" value="$MD_5"/>
      <attribute defType="com.stambia.flow.field.target" id="_PnMyvpcQEeuuFLoH_iEI2Q" value="$MD_5"/>
      <attribute defType="com.stambia.flow.field.location" id="_PnMyv5cQEeuuFLoH_iEI2Q" value="SRC"/>
      <attribute defType="com.stambia.flow.field.version" id="_PnMywJcQEeuuFLoH_iEI2Q" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_PnMywZcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_PnMywpcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.source" id="_PnMyw5cQEeuuFLoH_iEI2Q">
        <values>$MD_6</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_PnMyxJcQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_TMP.%{MD_6}%</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_PnMyxZcQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_TMP</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.expr" id="_PnMyxpcQEeuuFLoH_iEI2Q" value="'IND_SESSION_FILE_OP_TMP.%{MD_6}%'"/>
    </node>
    <node defType="com.stambia.flow.field" id="_PnMyx5cQEeuuFLoH_iEI2Q" name="ACT_NAME">
      <attribute defType="com.stambia.flow.field.tag" id="_PnMyyJcQEeuuFLoH_iEI2Q"/>
      <attribute defType="com.stambia.flow.field.workname" id="_PnMyyZcQEeuuFLoH_iEI2Q" value="ACT_NAME"/>
      <attribute defType="com.stambia.flow.field.base" id="_PnMyypcQEeuuFLoH_iEI2Q" value="$MD_7"/>
      <attribute defType="com.stambia.flow.field.target" id="_PnMyy5cQEeuuFLoH_iEI2Q" value="$MD_7"/>
      <attribute defType="com.stambia.flow.field.location" id="_PnMyzJcQEeuuFLoH_iEI2Q" value="SRC"/>
      <attribute defType="com.stambia.flow.field.version" id="_PnMyzZcQEeuuFLoH_iEI2Q" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_PnMyzpcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_PnMyz5cQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.source" id="_PnMy0JcQEeuuFLoH_iEI2Q">
        <values>$MD_8</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_PnMy0ZcQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_TMP.%{MD_8}%</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_PnMy0pcQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_TMP</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.expr" id="_PnMy05cQEeuuFLoH_iEI2Q" value="'IND_SESSION_FILE_OP_TMP.%{MD_8}%'"/>
    </node>
    <node defType="com.stambia.flow.field" id="_PnMy1JcQEeuuFLoH_iEI2Q" name="ACT_ITER">
      <attribute defType="com.stambia.flow.field.tag" id="_PnMy1ZcQEeuuFLoH_iEI2Q"/>
      <attribute defType="com.stambia.flow.field.workname" id="_PnMy1pcQEeuuFLoH_iEI2Q" value="ACT_ITER"/>
      <attribute defType="com.stambia.flow.field.base" id="_PnMy15cQEeuuFLoH_iEI2Q" value="$MD_9"/>
      <attribute defType="com.stambia.flow.field.target" id="_PnMy2JcQEeuuFLoH_iEI2Q" value="$MD_9"/>
      <attribute defType="com.stambia.flow.field.location" id="_PnMy2ZcQEeuuFLoH_iEI2Q" value="SRC"/>
      <attribute defType="com.stambia.flow.field.version" id="_PnMy2pcQEeuuFLoH_iEI2Q" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_PnMy25cQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_PnMy3JcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.source" id="_PnMy3ZcQEeuuFLoH_iEI2Q">
        <values>$MD_10</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_PnMy3pcQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_TMP.%{MD_10}%</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_PnMy35cQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_TMP</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.expr" id="_PnMy4JcQEeuuFLoH_iEI2Q" value="'IND_SESSION_FILE_OP_TMP.%{MD_10}%'"/>
    </node>
    <node defType="com.stambia.flow.field" id="_PnMy4ZcQEeuuFLoH_iEI2Q" name="FILE_ID">
      <attribute defType="com.stambia.flow.field.tag" id="_PnMy4pcQEeuuFLoH_iEI2Q"/>
      <attribute defType="com.stambia.flow.field.workname" id="_PnMy45cQEeuuFLoH_iEI2Q" value="FILE_ID"/>
      <attribute defType="com.stambia.flow.field.base" id="_PnMy5JcQEeuuFLoH_iEI2Q" value="$MD_11"/>
      <attribute defType="com.stambia.flow.field.target" id="_PnMy5ZcQEeuuFLoH_iEI2Q" value="$MD_11"/>
      <attribute defType="com.stambia.flow.field.location" id="_PnMy5pcQEeuuFLoH_iEI2Q" value="SRC"/>
      <attribute defType="com.stambia.flow.field.version" id="_PnMy55cQEeuuFLoH_iEI2Q" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_PnMy6JcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_PnMy6ZcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.source" id="_PnMy6pcQEeuuFLoH_iEI2Q">
        <values>$MD_12</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_PnMy65cQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_TMP.%{MD_12}%</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_PnMy7JcQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_TMP</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.expr" id="_PnMy7ZcQEeuuFLoH_iEI2Q" value="'IND_SESSION_FILE_OP_TMP.%{MD_12}%'"/>
    </node>
    <node defType="com.stambia.flow.field" id="_PnMy7pcQEeuuFLoH_iEI2Q" name="FILE_OPERATION">
      <attribute defType="com.stambia.flow.field.tag" id="_PnMy75cQEeuuFLoH_iEI2Q"/>
      <attribute defType="com.stambia.flow.field.workname" id="_PnMy8JcQEeuuFLoH_iEI2Q" value="FILE_OPERATION"/>
      <attribute defType="com.stambia.flow.field.base" id="_PnMy8ZcQEeuuFLoH_iEI2Q" value="$MD_13"/>
      <attribute defType="com.stambia.flow.field.target" id="_PnMy8pcQEeuuFLoH_iEI2Q" value="$MD_13"/>
      <attribute defType="com.stambia.flow.field.location" id="_PnMy85cQEeuuFLoH_iEI2Q" value="SRC"/>
      <attribute defType="com.stambia.flow.field.version" id="_PnMy9JcQEeuuFLoH_iEI2Q" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_PnMy9ZcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_PnMy9pcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.source" id="_PnMy95cQEeuuFLoH_iEI2Q">
        <values>$MD_14</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_PnMy-JcQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_TMP.%{MD_14}%</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_PnMy-ZcQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_TMP</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.expr" id="_PnMy-pcQEeuuFLoH_iEI2Q" value="'IND_SESSION_FILE_OP_TMP.%{MD_14}%'"/>
    </node>
    <node defType="com.stambia.flow.field" id="_PnNZsJcQEeuuFLoH_iEI2Q" name="FILE_NAME">
      <attribute defType="com.stambia.flow.field.tag" id="_PnNZsZcQEeuuFLoH_iEI2Q"/>
      <attribute defType="com.stambia.flow.field.workname" id="_PnNZspcQEeuuFLoH_iEI2Q" value="FILE_NAME"/>
      <attribute defType="com.stambia.flow.field.base" id="_PnNZs5cQEeuuFLoH_iEI2Q" value="$MD_15"/>
      <attribute defType="com.stambia.flow.field.target" id="_PnNZtJcQEeuuFLoH_iEI2Q" value="$MD_15"/>
      <attribute defType="com.stambia.flow.field.location" id="_PnNZtZcQEeuuFLoH_iEI2Q" value="SRC"/>
      <attribute defType="com.stambia.flow.field.version" id="_PnNZtpcQEeuuFLoH_iEI2Q" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_PnNZt5cQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_PnNZuJcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.updatekey" id="_PnNZuZcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.source" id="_PnNZupcQEeuuFLoH_iEI2Q">
        <values>$MD_16</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_PnNZu5cQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_TMP.%{MD_16}%</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_PnNZvJcQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_TMP</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.expr" id="_PnNZvZcQEeuuFLoH_iEI2Q" value="'IND_SESSION_FILE_OP_TMP.%{MD_16}%'"/>
    </node>
    <node defType="com.stambia.flow.field" id="_PnNZvpcQEeuuFLoH_iEI2Q" name="FILE_DIR">
      <attribute defType="com.stambia.flow.field.tag" id="_PnNZv5cQEeuuFLoH_iEI2Q"/>
      <attribute defType="com.stambia.flow.field.workname" id="_PnNZwJcQEeuuFLoH_iEI2Q" value="FILE_DIR"/>
      <attribute defType="com.stambia.flow.field.base" id="_PnNZwZcQEeuuFLoH_iEI2Q" value="$MD_17"/>
      <attribute defType="com.stambia.flow.field.target" id="_PnNZwpcQEeuuFLoH_iEI2Q" value="$MD_17"/>
      <attribute defType="com.stambia.flow.field.location" id="_PnNZw5cQEeuuFLoH_iEI2Q" value="SRC"/>
      <attribute defType="com.stambia.flow.field.version" id="_PnNZxJcQEeuuFLoH_iEI2Q" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_PnNZxZcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_PnNZxpcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.updatekey" id="_PnNZx5cQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.source" id="_PnNZyJcQEeuuFLoH_iEI2Q">
        <values>$MD_18</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_PnNZyZcQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_TMP.%{MD_18}%</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_PnNZypcQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_TMP</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.expr" id="_PnNZy5cQEeuuFLoH_iEI2Q" value="'IND_SESSION_FILE_OP_TMP.%{MD_18}%'"/>
    </node>
    <node defType="com.stambia.flow.field" id="_PnNZzJcQEeuuFLoH_iEI2Q" name="ESTADO">
      <attribute defType="com.stambia.flow.field.tag" id="_PnNZzZcQEeuuFLoH_iEI2Q"/>
      <attribute defType="com.stambia.flow.field.workname" id="_PnNZzpcQEeuuFLoH_iEI2Q" value="ESTADO"/>
      <attribute defType="com.stambia.flow.field.base" id="_PnNZz5cQEeuuFLoH_iEI2Q" value="$MD_19"/>
      <attribute defType="com.stambia.flow.field.target" id="_PnNZ0JcQEeuuFLoH_iEI2Q" value="$MD_19"/>
      <attribute defType="com.stambia.flow.field.location" id="_PnNZ0ZcQEeuuFLoH_iEI2Q" value="SRC"/>
      <attribute defType="com.stambia.flow.field.version" id="_PnNZ0pcQEeuuFLoH_iEI2Q" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_PnNZ05cQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_PnNZ1JcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.source" id="_PnNZ1ZcQEeuuFLoH_iEI2Q">
        <values>$MD_20</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_PnNZ1pcQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_TMP.%{MD_20}%</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_PnNZ15cQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_TMP</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.expr" id="_PnNZ2JcQEeuuFLoH_iEI2Q" value="'IND_SESSION_FILE_OP_TMP.%{MD_20}%'"/>
    </node>
    <node defType="com.stambia.flow.field" id="_PnNZ2ZcQEeuuFLoH_iEI2Q" name="RUTA_AZURE">
      <attribute defType="com.stambia.flow.field.tag" id="_PnNZ2pcQEeuuFLoH_iEI2Q"/>
      <attribute defType="com.stambia.flow.field.workname" id="_PnNZ25cQEeuuFLoH_iEI2Q" value="RUTA_AZURE"/>
      <attribute defType="com.stambia.flow.field.base" id="_PnNZ3JcQEeuuFLoH_iEI2Q" value="$MD_21"/>
      <attribute defType="com.stambia.flow.field.target" id="_PnNZ3ZcQEeuuFLoH_iEI2Q" value="$MD_21"/>
      <attribute defType="com.stambia.flow.field.location" id="_PnNZ3pcQEeuuFLoH_iEI2Q" value="SRC"/>
      <attribute defType="com.stambia.flow.field.version" id="_PnNZ35cQEeuuFLoH_iEI2Q" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_PnNZ4JcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_PnNZ4ZcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.source" id="_PnNZ4pcQEeuuFLoH_iEI2Q">
        <values>$MD_18</values>
        <values>$MD_23</values>
        <values>$MD_24</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_PnNZ45cQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_TMP.%{MD_18}%</values>
        <values>STB_PARAM_NASAZURE.%{MD_23}%</values>
        <values>STB_PARAM_NASAZURE.%{MD_24}%</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_PnNZ5JcQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_TMP</values>
        <values>STB_PARAM_NASAZURE</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.expr" id="_PnNZ5ZcQEeuuFLoH_iEI2Q" value="'REPLACE(IND_SESSION_FILE_OP_TMP.%{MD_18}%,STB_PARAM_NASAZURE.%{MD_23}%,STB_PARAM_NASAZURE.%{MD_24}%)'"/>
    </node>
    <node defType="com.stambia.flow.field" id="_PnNZ5pcQEeuuFLoH_iEI2Q" name="FILE_LENGTH">
      <attribute defType="com.stambia.flow.field.tag" id="_PnNZ55cQEeuuFLoH_iEI2Q"/>
      <attribute defType="com.stambia.flow.field.workname" id="_PnNZ6JcQEeuuFLoH_iEI2Q" value="FILE_LENGTH"/>
      <attribute defType="com.stambia.flow.field.base" id="_PnNZ6ZcQEeuuFLoH_iEI2Q" value="$MD_25"/>
      <attribute defType="com.stambia.flow.field.target" id="_PnNZ6pcQEeuuFLoH_iEI2Q" value="$MD_25"/>
      <attribute defType="com.stambia.flow.field.location" id="_PnNZ65cQEeuuFLoH_iEI2Q" value="SRC"/>
      <attribute defType="com.stambia.flow.field.version" id="_PnNZ7JcQEeuuFLoH_iEI2Q" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_PnNZ7ZcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_PnNZ7pcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.source" id="_PnNZ75cQEeuuFLoH_iEI2Q">
        <values>$MD_26</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_PnNZ8JcQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_TMP.%{MD_26}%</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_PnNZ8ZcQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_TMP</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.expr" id="_PnNZ8pcQEeuuFLoH_iEI2Q" value="'IND_SESSION_FILE_OP_TMP.%{MD_26}%'"/>
    </node>
    <node defType="com.stambia.flow.field" id="_PnNZ85cQEeuuFLoH_iEI2Q" name="FILE_LAST_MODIFIED_DATE">
      <attribute defType="com.stambia.flow.field.tag" id="_PnNZ9JcQEeuuFLoH_iEI2Q"/>
      <attribute defType="com.stambia.flow.field.workname" id="_PnNZ9ZcQEeuuFLoH_iEI2Q" value="FILE_LAST_MODIFIED_DATE"/>
      <attribute defType="com.stambia.flow.field.base" id="_PnNZ9pcQEeuuFLoH_iEI2Q" value="$MD_27"/>
      <attribute defType="com.stambia.flow.field.target" id="_PnNZ95cQEeuuFLoH_iEI2Q" value="$MD_27"/>
      <attribute defType="com.stambia.flow.field.location" id="_PnNZ-JcQEeuuFLoH_iEI2Q" value="SRC"/>
      <attribute defType="com.stambia.flow.field.version" id="_PnNZ-ZcQEeuuFLoH_iEI2Q" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_PnNZ-pcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_PnNZ-5cQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.source" id="_PnNZ_JcQEeuuFLoH_iEI2Q">
        <values>$MD_28</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_PnNZ_ZcQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_TMP.%{MD_28}%</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_PnNZ_pcQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_TMP</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.expr" id="_PnNZ_5cQEeuuFLoH_iEI2Q" value="'IND_SESSION_FILE_OP_TMP.%{MD_28}%'"/>
    </node>
    <node defType="com.stambia.flow.field" id="_PnNaAJcQEeuuFLoH_iEI2Q" name="FILE_TO_DIR">
      <attribute defType="com.stambia.flow.field.tag" id="_PnNaAZcQEeuuFLoH_iEI2Q"/>
      <attribute defType="com.stambia.flow.field.workname" id="_PnNaApcQEeuuFLoH_iEI2Q" value="FILE_TO_DIR"/>
      <attribute defType="com.stambia.flow.field.base" id="_PnNaA5cQEeuuFLoH_iEI2Q" value="$MD_29"/>
      <attribute defType="com.stambia.flow.field.target" id="_PnNaBJcQEeuuFLoH_iEI2Q" value="$MD_29"/>
      <attribute defType="com.stambia.flow.field.location" id="_PnNaBZcQEeuuFLoH_iEI2Q" value="SRC"/>
      <attribute defType="com.stambia.flow.field.version" id="_PnNaBpcQEeuuFLoH_iEI2Q" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_PnNaB5cQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_PnNaCJcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.source" id="_PnNaCZcQEeuuFLoH_iEI2Q">
        <values>$MD_30</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_PnNaCpcQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_TMP.%{MD_30}%</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_PnNaC5cQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_TMP</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.expr" id="_PnNaDJcQEeuuFLoH_iEI2Q" value="'IND_SESSION_FILE_OP_TMP.%{MD_30}%'"/>
    </node>
    <node defType="com.stambia.flow.field" id="_PnNaDZcQEeuuFLoH_iEI2Q" name="FILE_TO_FILE">
      <attribute defType="com.stambia.flow.field.tag" id="_PnNaDpcQEeuuFLoH_iEI2Q"/>
      <attribute defType="com.stambia.flow.field.workname" id="_PnNaD5cQEeuuFLoH_iEI2Q" value="FILE_TO_FILE"/>
      <attribute defType="com.stambia.flow.field.base" id="_PnNaEJcQEeuuFLoH_iEI2Q" value="$MD_31"/>
      <attribute defType="com.stambia.flow.field.target" id="_PnNaEZcQEeuuFLoH_iEI2Q" value="$MD_31"/>
      <attribute defType="com.stambia.flow.field.location" id="_PnNaEpcQEeuuFLoH_iEI2Q" value="SRC"/>
      <attribute defType="com.stambia.flow.field.version" id="_PnNaE5cQEeuuFLoH_iEI2Q" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_PnNaFJcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_PnNaFZcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.source" id="_PnNaFpcQEeuuFLoH_iEI2Q">
        <values>$MD_32</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_PnNaF5cQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_TMP.%{MD_32}%</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_PnNaGJcQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_TMP</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.expr" id="_PnNaGZcQEeuuFLoH_iEI2Q" value="'IND_SESSION_FILE_OP_TMP.%{MD_32}%'"/>
    </node>
    <node defType="com.stambia.flow.field" id="_PnNaGpcQEeuuFLoH_iEI2Q" name="FILE_OPERATION_DATE">
      <attribute defType="com.stambia.flow.field.tag" id="_PnNaG5cQEeuuFLoH_iEI2Q"/>
      <attribute defType="com.stambia.flow.field.workname" id="_PnNaHJcQEeuuFLoH_iEI2Q" value="FILE_OPERATION_DATE"/>
      <attribute defType="com.stambia.flow.field.base" id="_PnNaHZcQEeuuFLoH_iEI2Q" value="$MD_33"/>
      <attribute defType="com.stambia.flow.field.target" id="_PnNaHpcQEeuuFLoH_iEI2Q" value="$MD_33"/>
      <attribute defType="com.stambia.flow.field.location" id="_PnNaH5cQEeuuFLoH_iEI2Q" value="SRC"/>
      <attribute defType="com.stambia.flow.field.version" id="_PnNaIJcQEeuuFLoH_iEI2Q" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_PnNaIZcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_PnNaIpcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.source" id="_PnOAwJcQEeuuFLoH_iEI2Q">
        <values>$MD_34</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_PnOAwZcQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_TMP.%{MD_34}%</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_PnOAwpcQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_TMP</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.expr" id="_PnOAw5cQEeuuFLoH_iEI2Q" value="'IND_SESSION_FILE_OP_TMP.%{MD_34}%'"/>
    </node>
    <node defType="com.stambia.flow.field" id="_PnOAxJcQEeuuFLoH_iEI2Q" name="STATUS">
      <attribute defType="com.stambia.flow.field.tag" id="_PnOAxZcQEeuuFLoH_iEI2Q"/>
      <attribute defType="com.stambia.flow.field.workname" id="_PnOAxpcQEeuuFLoH_iEI2Q" value="STATUS"/>
      <attribute defType="com.stambia.flow.field.base" id="_PnOAx5cQEeuuFLoH_iEI2Q" value="$MD_35"/>
      <attribute defType="com.stambia.flow.field.target" id="_PnOAyJcQEeuuFLoH_iEI2Q" value="$MD_35"/>
      <attribute defType="com.stambia.flow.field.location" id="_PnOAyZcQEeuuFLoH_iEI2Q" value="SRC"/>
      <attribute defType="com.stambia.flow.field.version" id="_PnOAypcQEeuuFLoH_iEI2Q" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_PnOAy5cQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_PnOAzJcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.source" id="_PnOAzZcQEeuuFLoH_iEI2Q">
        <values>$MD_36</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_PnOAzpcQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_TMP.%{MD_36}%</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_PnOAz5cQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_TMP</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.expr" id="_PnOA0JcQEeuuFLoH_iEI2Q" value="'IND_SESSION_FILE_OP_TMP.%{MD_36}%'"/>
    </node>
    <node defType="com.stambia.flow.field" id="_PnOA0ZcQEeuuFLoH_iEI2Q" name="STATUS_COMMENT">
      <attribute defType="com.stambia.flow.field.tag" id="_PnOA0pcQEeuuFLoH_iEI2Q"/>
      <attribute defType="com.stambia.flow.field.workname" id="_PnOA05cQEeuuFLoH_iEI2Q" value="STATUS_COMMENT"/>
      <attribute defType="com.stambia.flow.field.base" id="_PnOA1JcQEeuuFLoH_iEI2Q" value="$MD_37"/>
      <attribute defType="com.stambia.flow.field.target" id="_PnOA1ZcQEeuuFLoH_iEI2Q" value="$MD_37"/>
      <attribute defType="com.stambia.flow.field.location" id="_PnOA1pcQEeuuFLoH_iEI2Q" value="SRC"/>
      <attribute defType="com.stambia.flow.field.version" id="_PnOA15cQEeuuFLoH_iEI2Q" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_PnOA2JcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_PnOA2ZcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.source" id="_PnOA2pcQEeuuFLoH_iEI2Q">
        <values>$MD_38</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_PnOA25cQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_TMP.%{MD_38}%</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_PnOA3JcQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_TMP</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.expr" id="_PnOA3ZcQEeuuFLoH_iEI2Q" value="'IND_SESSION_FILE_OP_TMP.%{MD_38}%'"/>
    </node>
    <node defType="com.stambia.flow.field" id="_PnOA3pcQEeuuFLoH_iEI2Q" name="STATUS_DATE">
      <attribute defType="com.stambia.flow.field.tag" id="_PnOA35cQEeuuFLoH_iEI2Q"/>
      <attribute defType="com.stambia.flow.field.workname" id="_PnOA4JcQEeuuFLoH_iEI2Q" value="STATUS_DATE"/>
      <attribute defType="com.stambia.flow.field.base" id="_PnOA4ZcQEeuuFLoH_iEI2Q" value="$MD_39"/>
      <attribute defType="com.stambia.flow.field.target" id="_PnOA4pcQEeuuFLoH_iEI2Q" value="$MD_39"/>
      <attribute defType="com.stambia.flow.field.location" id="_PnOA45cQEeuuFLoH_iEI2Q" value="SRC"/>
      <attribute defType="com.stambia.flow.field.version" id="_PnOA5JcQEeuuFLoH_iEI2Q" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_PnOA5ZcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_PnOA5pcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.source" id="_PnOA55cQEeuuFLoH_iEI2Q">
        <values>$MD_40</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_PnOA6JcQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_TMP.%{MD_40}%</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_PnOA6ZcQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_TMP</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.expr" id="_PnOA6pcQEeuuFLoH_iEI2Q" value="'IND_SESSION_FILE_OP_TMP.%{MD_40}%'"/>
    </node>
    <node defType="com.stambia.flow.field" id="_PnOA65cQEeuuFLoH_iEI2Q" name="USER_COMMENT">
      <attribute defType="com.stambia.flow.field.tag" id="_PnOA7JcQEeuuFLoH_iEI2Q"/>
      <attribute defType="com.stambia.flow.field.workname" id="_PnOA7ZcQEeuuFLoH_iEI2Q" value="USER_COMMENT"/>
      <attribute defType="com.stambia.flow.field.base" id="_PnOA7pcQEeuuFLoH_iEI2Q" value="$MD_41"/>
      <attribute defType="com.stambia.flow.field.target" id="_PnOA75cQEeuuFLoH_iEI2Q" value="$MD_41"/>
      <attribute defType="com.stambia.flow.field.location" id="_PnOA8JcQEeuuFLoH_iEI2Q" value="SRC"/>
      <attribute defType="com.stambia.flow.field.version" id="_PnOA8ZcQEeuuFLoH_iEI2Q" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_PnOA8pcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_PnOA85cQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.source" id="_PnOA9JcQEeuuFLoH_iEI2Q">
        <values>$MD_42</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_PnOA9ZcQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_TMP.%{MD_42}%</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_PnOA9pcQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_TMP</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.expr" id="_PnOA95cQEeuuFLoH_iEI2Q" value="'IND_SESSION_FILE_OP_TMP.%{MD_42}%'"/>
    </node>
    <node defType="com.stambia.flow.field" id="_PnOA-JcQEeuuFLoH_iEI2Q" name="USER_FLAG">
      <attribute defType="com.stambia.flow.field.tag" id="_PnOA-ZcQEeuuFLoH_iEI2Q"/>
      <attribute defType="com.stambia.flow.field.workname" id="_PnOA-pcQEeuuFLoH_iEI2Q" value="USER_FLAG"/>
      <attribute defType="com.stambia.flow.field.base" id="_PnOA-5cQEeuuFLoH_iEI2Q" value="$MD_43"/>
      <attribute defType="com.stambia.flow.field.target" id="_PnOA_JcQEeuuFLoH_iEI2Q" value="$MD_43"/>
      <attribute defType="com.stambia.flow.field.location" id="_PnOA_ZcQEeuuFLoH_iEI2Q" value="SRC"/>
      <attribute defType="com.stambia.flow.field.version" id="_PnOA_pcQEeuuFLoH_iEI2Q" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_PnOA_5cQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_PnOBAJcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.source" id="_PnOBAZcQEeuuFLoH_iEI2Q">
        <values>$MD_44</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_PnOBApcQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_TMP.%{MD_44}%</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_PnOBA5cQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_TMP</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.expr" id="_PnOBBJcQEeuuFLoH_iEI2Q" value="'IND_SESSION_FILE_OP_TMP.%{MD_44}%'"/>
    </node>
    <node defType="com.stambia.flow.field" id="_PnOBBZcQEeuuFLoH_iEI2Q" name="USER_DATE">
      <attribute defType="com.stambia.flow.field.tag" id="_PnOBBpcQEeuuFLoH_iEI2Q"/>
      <attribute defType="com.stambia.flow.field.workname" id="_PnOBB5cQEeuuFLoH_iEI2Q" value="USER_DATE"/>
      <attribute defType="com.stambia.flow.field.base" id="_PnOBCJcQEeuuFLoH_iEI2Q" value="$MD_45"/>
      <attribute defType="com.stambia.flow.field.target" id="_PnOBCZcQEeuuFLoH_iEI2Q" value="$MD_45"/>
      <attribute defType="com.stambia.flow.field.location" id="_PnOBCpcQEeuuFLoH_iEI2Q" value="SRC"/>
      <attribute defType="com.stambia.flow.field.version" id="_PnOBC5cQEeuuFLoH_iEI2Q" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_PnOBDJcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_PnOBDZcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.source" id="_PnOBDpcQEeuuFLoH_iEI2Q">
        <values>$MD_46</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_PnOBD5cQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_TMP.%{MD_46}%</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_PnOBEJcQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_TMP</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.expr" id="_PnOBEZcQEeuuFLoH_iEI2Q" value="'IND_SESSION_FILE_OP_TMP.%{MD_46}%'"/>
    </node>
    <node defType="com.stambia.flow.field" id="_PnOBEpcQEeuuFLoH_iEI2Q" name="FILE_IS_HIDDEN">
      <attribute defType="com.stambia.flow.field.tag" id="_PnOBE5cQEeuuFLoH_iEI2Q"/>
      <attribute defType="com.stambia.flow.field.workname" id="_PnOBFJcQEeuuFLoH_iEI2Q" value="FILE_IS_HIDDEN"/>
      <attribute defType="com.stambia.flow.field.base" id="_PnOBFZcQEeuuFLoH_iEI2Q" value="$MD_47"/>
      <attribute defType="com.stambia.flow.field.target" id="_PnOBFpcQEeuuFLoH_iEI2Q" value="$MD_47"/>
      <attribute defType="com.stambia.flow.field.location" id="_PnOBF5cQEeuuFLoH_iEI2Q" value="SRC"/>
      <attribute defType="com.stambia.flow.field.version" id="_PnOBGJcQEeuuFLoH_iEI2Q" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_PnOBGZcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_PnOBGpcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.source" id="_PnOBG5cQEeuuFLoH_iEI2Q">
        <values>$MD_48</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_PnOBHJcQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_TMP.%{MD_48}%</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_PnOBHZcQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_TMP</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.expr" id="_PnOBHpcQEeuuFLoH_iEI2Q" value="'IND_SESSION_FILE_OP_TMP.%{MD_48}%'"/>
    </node>
    <node defType="com.stambia.flow.field" id="_PnOBH5cQEeuuFLoH_iEI2Q" name="FILE_LAST_MODIFIED">
      <attribute defType="com.stambia.flow.field.tag" id="_PnOBIJcQEeuuFLoH_iEI2Q"/>
      <attribute defType="com.stambia.flow.field.workname" id="_PnOBIZcQEeuuFLoH_iEI2Q" value="FILE_LAST_MODIFIED"/>
      <attribute defType="com.stambia.flow.field.base" id="_PnOBIpcQEeuuFLoH_iEI2Q" value="$MD_49"/>
      <attribute defType="com.stambia.flow.field.target" id="_PnOBI5cQEeuuFLoH_iEI2Q" value="$MD_49"/>
      <attribute defType="com.stambia.flow.field.location" id="_PnOBJJcQEeuuFLoH_iEI2Q" value="SRC"/>
      <attribute defType="com.stambia.flow.field.version" id="_PnOBJZcQEeuuFLoH_iEI2Q" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_PnOBJpcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_PnOBJ5cQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.source" id="_PnOBKJcQEeuuFLoH_iEI2Q">
        <values>$MD_50</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_PnOBKZcQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_TMP.%{MD_50}%</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_PnOBKpcQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_TMP</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.expr" id="_PnOBK5cQEeuuFLoH_iEI2Q" value="'IND_SESSION_FILE_OP_TMP.%{MD_50}%'"/>
    </node>
    <node defType="com.stambia.flow.field" id="_PnOBLJcQEeuuFLoH_iEI2Q" name="FILE_CAN_READ">
      <attribute defType="com.stambia.flow.field.tag" id="_PnOBLZcQEeuuFLoH_iEI2Q"/>
      <attribute defType="com.stambia.flow.field.workname" id="_PnOBLpcQEeuuFLoH_iEI2Q" value="FILE_CAN_READ"/>
      <attribute defType="com.stambia.flow.field.base" id="_PnOBL5cQEeuuFLoH_iEI2Q" value="$MD_51"/>
      <attribute defType="com.stambia.flow.field.target" id="_PnOBMJcQEeuuFLoH_iEI2Q" value="$MD_51"/>
      <attribute defType="com.stambia.flow.field.location" id="_PnOBMZcQEeuuFLoH_iEI2Q" value="SRC"/>
      <attribute defType="com.stambia.flow.field.version" id="_PnOBMpcQEeuuFLoH_iEI2Q" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_PnOBM5cQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_PnOBNJcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.source" id="_PnOBNZcQEeuuFLoH_iEI2Q">
        <values>$MD_52</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_PnOn0JcQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_TMP.%{MD_52}%</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_PnOn0ZcQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_TMP</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.expr" id="_PnOn0pcQEeuuFLoH_iEI2Q" value="'IND_SESSION_FILE_OP_TMP.%{MD_52}%'"/>
    </node>
    <node defType="com.stambia.flow.field" id="_PnOn05cQEeuuFLoH_iEI2Q" name="FILE_CAN_WRITE">
      <attribute defType="com.stambia.flow.field.tag" id="_PnOn1JcQEeuuFLoH_iEI2Q"/>
      <attribute defType="com.stambia.flow.field.workname" id="_PnOn1ZcQEeuuFLoH_iEI2Q" value="FILE_CAN_WRITE"/>
      <attribute defType="com.stambia.flow.field.base" id="_PnOn1pcQEeuuFLoH_iEI2Q" value="$MD_53"/>
      <attribute defType="com.stambia.flow.field.target" id="_PnOn15cQEeuuFLoH_iEI2Q" value="$MD_53"/>
      <attribute defType="com.stambia.flow.field.location" id="_PnOn2JcQEeuuFLoH_iEI2Q" value="SRC"/>
      <attribute defType="com.stambia.flow.field.version" id="_PnOn2ZcQEeuuFLoH_iEI2Q" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_PnOn2pcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_PnOn25cQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.source" id="_PnOn3JcQEeuuFLoH_iEI2Q">
        <values>$MD_54</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_PnOn3ZcQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_TMP.%{MD_54}%</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_PnOn3pcQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_TMP</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.expr" id="_PnOn35cQEeuuFLoH_iEI2Q" value="'IND_SESSION_FILE_OP_TMP.%{MD_54}%'"/>
    </node>
    <node defType="com.stambia.flow.field" id="_PnOn4JcQEeuuFLoH_iEI2Q" name="FILE_CAN_EXECUTE">
      <attribute defType="com.stambia.flow.field.tag" id="_PnOn4ZcQEeuuFLoH_iEI2Q"/>
      <attribute defType="com.stambia.flow.field.workname" id="_PnOn4pcQEeuuFLoH_iEI2Q" value="FILE_CAN_EXECUTE"/>
      <attribute defType="com.stambia.flow.field.base" id="_PnOn45cQEeuuFLoH_iEI2Q" value="$MD_55"/>
      <attribute defType="com.stambia.flow.field.target" id="_PnOn5JcQEeuuFLoH_iEI2Q" value="$MD_55"/>
      <attribute defType="com.stambia.flow.field.location" id="_PnOn5ZcQEeuuFLoH_iEI2Q" value="SRC"/>
      <attribute defType="com.stambia.flow.field.version" id="_PnOn5pcQEeuuFLoH_iEI2Q" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_PnOn55cQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_PnOn6JcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.source" id="_PnOn6ZcQEeuuFLoH_iEI2Q">
        <values>$MD_56</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_PnOn6pcQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_TMP.%{MD_56}%</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_PnOn65cQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_TMP</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.expr" id="_PnOn7JcQEeuuFLoH_iEI2Q" value="'IND_SESSION_FILE_OP_TMP.%{MD_56}%'"/>
    </node>
    <node defType="com.stambia.flow.field" id="_PnOn7ZcQEeuuFLoH_iEI2Q" name="FILE_IS_DIRECTORY">
      <attribute defType="com.stambia.flow.field.tag" id="_PnOn7pcQEeuuFLoH_iEI2Q"/>
      <attribute defType="com.stambia.flow.field.workname" id="_PnOn75cQEeuuFLoH_iEI2Q" value="FILE_IS_DIRECTORY"/>
      <attribute defType="com.stambia.flow.field.base" id="_PnOn8JcQEeuuFLoH_iEI2Q" value="$MD_57"/>
      <attribute defType="com.stambia.flow.field.target" id="_PnOn8ZcQEeuuFLoH_iEI2Q" value="$MD_57"/>
      <attribute defType="com.stambia.flow.field.location" id="_PnOn8pcQEeuuFLoH_iEI2Q" value="SRC"/>
      <attribute defType="com.stambia.flow.field.version" id="_PnOn85cQEeuuFLoH_iEI2Q" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_PnOn9JcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_PnOn9ZcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.source" id="_PnOn9pcQEeuuFLoH_iEI2Q">
        <values>$MD_58</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_PnOn95cQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_TMP.%{MD_58}%</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_PnOn-JcQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_TMP</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.expr" id="_PnOn-ZcQEeuuFLoH_iEI2Q" value="'IND_SESSION_FILE_OP_TMP.%{MD_58}%'"/>
    </node>
    <node defType="com.stambia.flow.field" id="_PnOn-pcQEeuuFLoH_iEI2Q" name="FILE_FROM_DIR">
      <attribute defType="com.stambia.flow.field.tag" id="_PnOn-5cQEeuuFLoH_iEI2Q"/>
      <attribute defType="com.stambia.flow.field.workname" id="_PnOn_JcQEeuuFLoH_iEI2Q" value="FILE_FROM_DIR"/>
      <attribute defType="com.stambia.flow.field.base" id="_PnOn_ZcQEeuuFLoH_iEI2Q" value="$MD_59"/>
      <attribute defType="com.stambia.flow.field.target" id="_PnOn_pcQEeuuFLoH_iEI2Q" value="$MD_59"/>
      <attribute defType="com.stambia.flow.field.location" id="_PnOn_5cQEeuuFLoH_iEI2Q" value="SRC"/>
      <attribute defType="com.stambia.flow.field.version" id="_PnOoAJcQEeuuFLoH_iEI2Q" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_PnOoAZcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_PnOoApcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.source" id="_PnOoA5cQEeuuFLoH_iEI2Q">
        <values>$MD_60</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_PnOoBJcQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_TMP.%{MD_60}%</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_PnOoBZcQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_TMP</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.expr" id="_PnOoBpcQEeuuFLoH_iEI2Q" value="'IND_SESSION_FILE_OP_TMP.%{MD_60}%'"/>
    </node>
    <node defType="com.stambia.flow.field" id="_PnOoB5cQEeuuFLoH_iEI2Q" name="FILE_FROM_FILE">
      <attribute defType="com.stambia.flow.field.tag" id="_PnOoCJcQEeuuFLoH_iEI2Q"/>
      <attribute defType="com.stambia.flow.field.workname" id="_PnOoCZcQEeuuFLoH_iEI2Q" value="FILE_FROM_FILE"/>
      <attribute defType="com.stambia.flow.field.base" id="_PnOoCpcQEeuuFLoH_iEI2Q" value="$MD_61"/>
      <attribute defType="com.stambia.flow.field.target" id="_PnOoC5cQEeuuFLoH_iEI2Q" value="$MD_61"/>
      <attribute defType="com.stambia.flow.field.location" id="_PnOoDJcQEeuuFLoH_iEI2Q" value="SRC"/>
      <attribute defType="com.stambia.flow.field.version" id="_PnOoDZcQEeuuFLoH_iEI2Q" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_PnOoDpcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_PnOoD5cQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.source" id="_PnOoEJcQEeuuFLoH_iEI2Q">
        <values>$MD_62</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_PnOoEZcQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_TMP.%{MD_62}%</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_PnOoEpcQEeuuFLoH_iEI2Q">
        <values>IND_SESSION_FILE_OP_TMP</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.expr" id="_PnOoE5cQEeuuFLoH_iEI2Q" value="'IND_SESSION_FILE_OP_TMP.%{MD_62}%'"/>
    </node>
    <node defType="com.stambia.flow.field" id="_PnOoFJcQEeuuFLoH_iEI2Q" name="BORRADOLOCAL">
      <attribute defType="com.stambia.flow.field.tag" id="_PnOoFZcQEeuuFLoH_iEI2Q"/>
      <attribute defType="com.stambia.flow.field.workname" id="_PnOoFpcQEeuuFLoH_iEI2Q" value="BORRADOLOCAL"/>
      <attribute defType="com.stambia.flow.field.base" id="_PnOoF5cQEeuuFLoH_iEI2Q" value="$MD_63"/>
      <attribute defType="com.stambia.flow.field.target" id="_PnOoGJcQEeuuFLoH_iEI2Q" value="$MD_63"/>
      <attribute defType="com.stambia.flow.field.location" id="_PnOoGZcQEeuuFLoH_iEI2Q" value="SRC"/>
      <attribute defType="com.stambia.flow.field.version" id="_PnOoGpcQEeuuFLoH_iEI2Q" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_PnOoG5cQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_PnOoHJcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.source" id="_PnOoHZcQEeuuFLoH_iEI2Q">
        <values>$MD_64</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_PnOoHpcQEeuuFLoH_iEI2Q">
        <values>STB_PARAM_NASAZURE.%{MD_64}%</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_PnOoH5cQEeuuFLoH_iEI2Q">
        <values>STB_PARAM_NASAZURE</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.expr" id="_PnOoIJcQEeuuFLoH_iEI2Q" value="'STB_PARAM_NASAZURE.%{MD_64}%'"/>
    </node>
    <node defType="com.stambia.flow.field" id="_PnOoIZcQEeuuFLoH_iEI2Q" name="BORRADONUBE">
      <attribute defType="com.stambia.flow.field.tag" id="_PnOoIpcQEeuuFLoH_iEI2Q"/>
      <attribute defType="com.stambia.flow.field.workname" id="_PnOoI5cQEeuuFLoH_iEI2Q" value="BORRADONUBE"/>
      <attribute defType="com.stambia.flow.field.base" id="_PnOoJJcQEeuuFLoH_iEI2Q" value="$MD_65"/>
      <attribute defType="com.stambia.flow.field.target" id="_PnOoJZcQEeuuFLoH_iEI2Q" value="$MD_65"/>
      <attribute defType="com.stambia.flow.field.location" id="_PnOoJpcQEeuuFLoH_iEI2Q" value="SRC"/>
      <attribute defType="com.stambia.flow.field.version" id="_PnOoJ5cQEeuuFLoH_iEI2Q" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_PnOoKJcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_PnOoKZcQEeuuFLoH_iEI2Q" value="true"/>
      <attribute defType="com.stambia.flow.field.source" id="_PnOoKpcQEeuuFLoH_iEI2Q">
        <values>$MD_66</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_PnOoK5cQEeuuFLoH_iEI2Q">
        <values>STB_PARAM_NASAZURE.%{MD_66}%</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_PnOoLJcQEeuuFLoH_iEI2Q">
        <values>STB_PARAM_NASAZURE</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.expr" id="_PnOoLZcQEeuuFLoH_iEI2Q" value="'STB_PARAM_NASAZURE.%{MD_66}%'"/>
    </node>
  </node>
  <metaDataLink name="MD_0" target="../../Metadata/SQL_FILEDB.md#_dpGGMZBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=STB_PARAM_NASAZ_FILE?"/>
  <metaDataLink name="MD_1" target="../../Metadata/SQL_FILEDB.md#_dpP3MJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=SESS_ID?"/>
  <metaDataLink name="MD_2" target="../../Metadata/SQL_FILEDB.md#_ztS4MJCbEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=SESS_ID?"/>
  <metaDataLink name="MD_3" target="../../Metadata/SQL_FILEDB.md#_dpRsYJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=SESS_NAME?"/>
  <metaDataLink name="MD_4" target="../../Metadata/SQL_FILEDB.md#_ztUtYJCbEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=SESS_NAME?"/>
  <metaDataLink name="MD_5" target="../../Metadata/SQL_FILEDB.md#_dpThkJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=ACT_ID?"/>
  <metaDataLink name="MD_6" target="../../Metadata/SQL_FILEDB.md#_ztd3UJCbEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=ACT_ID?"/>
  <metaDataLink name="MD_7" target="../../Metadata/SQL_FILEDB.md#_dpVWwJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=ACT_NAME?"/>
  <metaDataLink name="MD_8" target="../../Metadata/SQL_FILEDB.md#_ztfFcJCbEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=ACT_NAME?"/>
  <metaDataLink name="MD_9" target="../../Metadata/SQL_FILEDB.md#_dpXL8JBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=ACT_ITER?"/>
  <metaDataLink name="MD_10" target="../../Metadata/SQL_FILEDB.md#_ztgTkJCbEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=ACT_ITER?"/>
  <metaDataLink name="MD_11" target="../../Metadata/SQL_FILEDB.md#_dpZBIJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=FILE_ID?"/>
  <metaDataLink name="MD_12" target="../../Metadata/SQL_FILEDB.md#_ztiIwJCbEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=FILE_ID?"/>
  <metaDataLink name="MD_13" target="../../Metadata/SQL_FILEDB.md#_dpa2UJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=FILE_OPERATION?"/>
  <metaDataLink name="MD_14" target="../../Metadata/SQL_FILEDB.md#_ztjW4JCbEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=FILE_OPERATION?"/>
  <metaDataLink name="MD_15" target="../../Metadata/SQL_FILEDB.md#_dpcEcJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=FILE_NAME?"/>
  <metaDataLink name="MD_16" target="../../Metadata/SQL_FILEDB.md#_ztklAJCbEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=FILE_NAME?"/>
  <metaDataLink name="MD_17" target="../../Metadata/SQL_FILEDB.md#_dpegsJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=FILE_DIR?"/>
  <metaDataLink name="MD_18" target="../../Metadata/SQL_FILEDB.md#_ztmaMJCbEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=FILE_DIR?"/>
  <metaDataLink name="MD_19" target="../../Metadata/SQL_FILEDB.md#_dpfu0JBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=ESTADO?"/>
  <metaDataLink name="MD_20" target="../../Metadata/SQL_FILEDB.md#_ztnoUJCbEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=ESTADO?"/>
  <metaDataLink name="MD_21" target="../../Metadata/SQL_FILEDB.md#_dphkAJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=RUTA_AZURE?"/>
  <metaDataLink name="MD_23" target="../../Metadata/SQL_FILEDB.md#_do0ZYJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=NOMCARPETA?"/>
  <metaDataLink name="MD_24" target="../../Metadata/SQL_FILEDB.md#_do8VMJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=RUTACLOUD?"/>
  <metaDataLink name="MD_25" target="../../Metadata/SQL_FILEDB.md#_dpjZMJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=FILE_LENGTH?"/>
  <metaDataLink name="MD_26" target="../../Metadata/SQL_FILEDB.md#_ztqEkJCbEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=FILE_LENGTH?"/>
  <metaDataLink name="MD_27" target="../../Metadata/SQL_FILEDB.md#_dplOYJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=FILE_LAST_MODIFIED_DATE?"/>
  <metaDataLink name="MD_28" target="../../Metadata/SQL_FILEDB.md#_ztrSsJCbEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=FILE_LAST_MODIFIED_DATE?"/>
  <metaDataLink name="MD_29" target="../../Metadata/SQL_FILEDB.md#_dpmcgJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=FILE_TO_DIR?"/>
  <metaDataLink name="MD_30" target="../../Metadata/SQL_FILEDB.md#_ztsg0JCbEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=FILE_TO_DIR?"/>
  <metaDataLink name="MD_31" target="../../Metadata/SQL_FILEDB.md#_dpoRsJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=FILE_TO_FILE?"/>
  <metaDataLink name="MD_32" target="../../Metadata/SQL_FILEDB.md#_zttu8JCbEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=FILE_TO_FILE?"/>
  <metaDataLink name="MD_33" target="../../Metadata/SQL_FILEDB.md#_dpqG4JBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=FILE_OPERATION_DATE?"/>
  <metaDataLink name="MD_34" target="../../Metadata/SQL_FILEDB.md#_ztu9EJCbEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=FILE_OPERATION_DATE?"/>
  <metaDataLink name="MD_35" target="../../Metadata/SQL_FILEDB.md#_dpr8EJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=STATUS?"/>
  <metaDataLink name="MD_36" target="../../Metadata/SQL_FILEDB.md#_ztwLMJCbEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=STATUS?"/>
  <metaDataLink name="MD_37" target="../../Metadata/SQL_FILEDB.md#_dptxQJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=STATUS_COMMENT?"/>
  <metaDataLink name="MD_38" target="../../Metadata/SQL_FILEDB.md#_ztxZUJCbEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=STATUS_COMMENT?"/>
  <metaDataLink name="MD_39" target="../../Metadata/SQL_FILEDB.md#_dpvmcJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=STATUS_DATE?"/>
  <metaDataLink name="MD_40" target="../../Metadata/SQL_FILEDB.md#_ztyncJCbEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=STATUS_DATE?"/>
  <metaDataLink name="MD_41" target="../../Metadata/SQL_FILEDB.md#_dpw0kJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=USER_COMMENT?"/>
  <metaDataLink name="MD_42" target="../../Metadata/SQL_FILEDB.md#_ztz1kJCbEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=USER_COMMENT?"/>
  <metaDataLink name="MD_43" target="../../Metadata/SQL_FILEDB.md#_dpypwJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=USER_FLAG?"/>
  <metaDataLink name="MD_44" target="../../Metadata/SQL_FILEDB.md#_zt1qwJCbEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=USER_FLAG?"/>
  <metaDataLink name="MD_45" target="../../Metadata/SQL_FILEDB.md#_dpz34JBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=USER_DATE?"/>
  <metaDataLink name="MD_46" target="../../Metadata/SQL_FILEDB.md#_zt244JCbEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=USER_DATE?"/>
  <metaDataLink name="MD_47" target="../../Metadata/SQL_FILEDB.md#_dp1tEJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=FILE_IS_HIDDEN?"/>
  <metaDataLink name="MD_48" target="../../Metadata/SQL_FILEDB.md#_zt4uEJCbEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=FILE_IS_HIDDEN?"/>
  <metaDataLink name="MD_49" target="../../Metadata/SQL_FILEDB.md#_dp3iQJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=FILE_LAST_MODIFIED?"/>
  <metaDataLink name="MD_50" target="../../Metadata/SQL_FILEDB.md#_zt58MJCbEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=FILE_LAST_MODIFIED?"/>
  <metaDataLink name="MD_51" target="../../Metadata/SQL_FILEDB.md#_dp4wYJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=FILE_CAN_READ?"/>
  <metaDataLink name="MD_52" target="../../Metadata/SQL_FILEDB.md#_zt7KUJCbEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=FILE_CAN_READ?"/>
  <metaDataLink name="MD_53" target="../../Metadata/SQL_FILEDB.md#_dp6lkJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=FILE_CAN_WRITE?"/>
  <metaDataLink name="MD_54" target="../../Metadata/SQL_FILEDB.md#_zt8YcJCbEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=FILE_CAN_WRITE?"/>
  <metaDataLink name="MD_55" target="../../Metadata/SQL_FILEDB.md#_dp8awJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=FILE_CAN_EXECUTE?"/>
  <metaDataLink name="MD_56" target="../../Metadata/SQL_FILEDB.md#_zt9mkJCbEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=FILE_CAN_EXECUTE?"/>
  <metaDataLink name="MD_57" target="../../Metadata/SQL_FILEDB.md#_dp-P8JBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=FILE_IS_DIRECTORY?"/>
  <metaDataLink name="MD_58" target="../../Metadata/SQL_FILEDB.md#_zt-0sJCbEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=FILE_IS_DIRECTORY?"/>
  <metaDataLink name="MD_59" target="../../Metadata/SQL_FILEDB.md#_dqPVsJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=FILE_FROM_DIR?"/>
  <metaDataLink name="MD_60" target="../../Metadata/SQL_FILEDB.md#_zuAC0JCbEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=FILE_FROM_DIR?"/>
  <metaDataLink name="MD_61" target="../../Metadata/SQL_FILEDB.md#_dqRK4JBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=FILE_FROM_FILE?"/>
  <metaDataLink name="MD_62" target="../../Metadata/SQL_FILEDB.md#_zuBQ8JCbEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=FILE_FROM_FILE?"/>
  <metaDataLink name="MD_63" target="../../Metadata/SQL_FILEDB.md#_yfvY8JDoEeu9G7DSepCQHA?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=BORRADOLOCAL?"/>
  <metaDataLink name="MD_64" target="../../Metadata/SQL_FILEDB.md#_do4q0JBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=BORRADOLOCAL?"/>
  <metaDataLink name="MD_65" target="../../Metadata/SQL_FILEDB.md#_yfxOIJDoEeu9G7DSepCQHA?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=BORRADONUBE?"/>
  <metaDataLink name="MD_66" target="../../Metadata/SQL_FILEDB.md#_do6gAJBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=BORRADONUBE?"/>
  <metaDataLink name="MD_70" target="../../Metadata/SQL_FILEDB.md#_ztJHMJCbEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=IND_SESSION_FILE_OP_TMP?"/>
  <metaDataLink name="MD_71" target="../../Metadata/SQL_FILEDB.md#_dotrsZBkEeuNkLbBPIrucw?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=STB_PARAM_NASAZURE?"/>
</md:node>