<?xml version="1.0" encoding="UTF-8"?>
<md:node xmlns:md="http://www.stambia.com/md" defType="com.stambia.flow" id="_Vri8kI6-EeurCtFmoi_SNA-flow" name="testFinal" md:ref="file:/C:/Users/D6855693/Documents/StambiaWorkspace_AZURE/.metadata/.plugins/com.indy.emf.uri/internalResource/technology/map/map.tech#_waYSMH8VEd2__Mzb_dB76A?fileId=_waYSMH8VEd2__Mzb_dB76A$type=tech$name=flow?">
  <node defType="com.stambia.flow.altId" id="_icuBoY7BEeurCtFmoi_SNA">
    <attribute defType="com.stambia.flow.altId.origin" id="_icuBoo7BEeurCtFmoi_SNA" value="mapping"/>
    <attribute defType="com.stambia.flow.altId.value" id="_icuBo47BEeurCtFmoi_SNA" value="_Vri8kI6-EeurCtFmoi_SNA"/>
  </node>
  <node defType="com.stambia.flow.step" id="037aca91-b48e-3c68-b834-259e811597af" name="I1_Sizes">
    <attribute defType="com.stambia.flow.step.desc" id="_icuosI7BEeurCtFmoi_SNA"/>
    <attribute defType="com.stambia.flow.step.type" id="_iczhMY7BEeurCtFmoi_SNA" value="Integration"/>
    <attribute defType="com.stambia.flow.step.target" id="_iczhMo7BEeurCtFmoi_SNA" value="$MD_0"/>
    <attribute defType="com.stambia.flow.step.srcProduct" id="_iczhM47BEeurCtFmoi_SNA"/>
    <attribute defType="com.stambia.flow.step.trgProduct" id="_iczhNI7BEeurCtFmoi_SNA" value="MICROSOFT_SQL_SERVER"/>
    <attribute defType="com.stambia.flow.step.tplCriteria" id="_iczhNY7BEeurCtFmoi_SNA" value="type=I-TP;trgProduct=MICROSOFT_SQL_SERVER;trgPath=server:SQL_FILEDB/schema:filecloudDB.test/datastore:Sizes;trgTech=RDBMS;trgWorkspaceCapability=true;trgMapCapability=true;trgFilterCapability=true;trgJoinCapability=true;srcTechList=RDBMS;srcProductList=MICROSOFT_SQL_SERVER"/>
    <attribute defType="com.stambia.flow.step.number" id="_iczhNo7BEeurCtFmoi_SNA" value="1"/>
    <node defType="com.stambia.flow.source" id="_ic0IWo7BEeurCtFmoi_SNA" name="Size2">
      <attribute defType="com.stambia.flow.source.target" id="_ic0IW47BEeurCtFmoi_SNA" value="$MD_5"/>
    </node>
    <node defType="com.stambia.flow.field" id="_ic0IQI7BEeurCtFmoi_SNA" name="ChainID">
      <attribute defType="com.stambia.flow.field.tag" id="_ic0IQY7BEeurCtFmoi_SNA"/>
      <attribute defType="com.stambia.flow.field.workname" id="_ic0IQo7BEeurCtFmoi_SNA" value="ChainID"/>
      <attribute defType="com.stambia.flow.field.base" id="_ic0IQ47BEeurCtFmoi_SNA" value="$MD_1"/>
      <attribute defType="com.stambia.flow.field.target" id="_ic0IRI7BEeurCtFmoi_SNA" value="$MD_1"/>
      <attribute defType="com.stambia.flow.field.location" id="_ic0IRY7BEeurCtFmoi_SNA" value="SRC"/>
      <attribute defType="com.stambia.flow.field.version" id="_ic0IRo7BEeurCtFmoi_SNA" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_ic0IR47BEeurCtFmoi_SNA" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_ic0ISI7BEeurCtFmoi_SNA" value="true"/>
      <attribute defType="com.stambia.flow.field.source" id="_ic0ISY7BEeurCtFmoi_SNA">
        <values>$MD_2</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_ic0ISo7BEeurCtFmoi_SNA">
        <values>Size2.%{MD_2}%</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_ic0IS47BEeurCtFmoi_SNA">
        <values>Size2</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.expr" id="_ic0ITI7BEeurCtFmoi_SNA" value="'Size2.%{MD_2}%'"/>
    </node>
    <node defType="com.stambia.flow.field" id="_ic0ITY7BEeurCtFmoi_SNA" name="width">
      <attribute defType="com.stambia.flow.field.tag" id="_ic0ITo7BEeurCtFmoi_SNA"/>
      <attribute defType="com.stambia.flow.field.workname" id="_ic0IT47BEeurCtFmoi_SNA" value="width"/>
      <attribute defType="com.stambia.flow.field.base" id="_ic0IUI7BEeurCtFmoi_SNA" value="$MD_3"/>
      <attribute defType="com.stambia.flow.field.target" id="_ic0IUY7BEeurCtFmoi_SNA" value="$MD_3"/>
      <attribute defType="com.stambia.flow.field.location" id="_ic0IUo7BEeurCtFmoi_SNA" value="SRC"/>
      <attribute defType="com.stambia.flow.field.version" id="_ic0IU47BEeurCtFmoi_SNA" value="2"/>
      <attribute defType="com.stambia.flow.field.insert" id="_ic0IVI7BEeurCtFmoi_SNA" value="true"/>
      <attribute defType="com.stambia.flow.field.update" id="_ic0IVY7BEeurCtFmoi_SNA" value="true"/>
      <attribute defType="com.stambia.flow.field.source" id="_ic0IVo7BEeurCtFmoi_SNA">
        <values>$MD_4</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceNames" id="_ic0IV47BEeurCtFmoi_SNA">
        <values>Size2.%{MD_4}%</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.sourceContainer" id="_ic0IWI7BEeurCtFmoi_SNA">
        <values>Size2</values>
      </attribute>
      <attribute defType="com.stambia.flow.field.expr" id="_ic0IWY7BEeurCtFmoi_SNA" value="'Size2.%{MD_4}%'"/>
    </node>
  </node>
  <metaDataLink name="MD_0" target="../../resource/NASAZ_PDF_CARGA/Metadata/SQL_FILEDB.md#_S8J-II6-EeurCtFmoi_SNA?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=Sizes?"/>
  <metaDataLink name="MD_1" target="../../resource/NASAZ_PDF_CARGA/Metadata/SQL_FILEDB.md#_S8t-0I6-EeurCtFmoi_SNA?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=ChainID?"/>
  <metaDataLink name="MD_2" target="../../resource/NASAZ_PDF_CARGA/Metadata/SQL_FILEDB.md#_S9ASsI6-EeurCtFmoi_SNA?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=ChainID?"/>
  <metaDataLink name="MD_3" target="../../resource/NASAZ_PDF_CARGA/Metadata/SQL_FILEDB.md#_S8zeYI6-EeurCtFmoi_SNA?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=width?"/>
  <metaDataLink name="MD_4" target="../../resource/NASAZ_PDF_CARGA/Metadata/SQL_FILEDB.md#_S9Cu8I6-EeurCtFmoi_SNA?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=width?"/>
  <metaDataLink name="MD_5" target="../../resource/NASAZ_PDF_CARGA/Metadata/SQL_FILEDB.md#_S88BQI6-EeurCtFmoi_SNA?fileId=_Cl4GoI0mEeudt4TkWBKkhg$type=md$name=Size2?"/>
</md:node>