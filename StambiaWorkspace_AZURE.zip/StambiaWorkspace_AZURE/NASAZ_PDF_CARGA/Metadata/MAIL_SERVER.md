<?xml version="1.0" encoding="UTF-8"?>
<md:node xmlns:md="http://www.stambia.com/md" defType="com.stambia.mail.server" id="_WDa8YJMkEeuaVLB2d1p41g" name="MailServer" md:ref="platform:/plugin/com.indy.environment/technology/web/mail.tech#UUID_STAMBIA_TECH_MAIL?fileId=UUID_STAMBIA_TECH_MAIL$type=tech$name=Email?">
  <node defType="com.stambia.mail.outgoingServer" id="_WmOugpMkEeuaVLB2d1p41g" name="SMTP Mail Server">
    <attribute defType="com.stambia.mail.outgoingServer.host" id="_nLOx4JMkEeuaVLB2d1p41g" value="172.30.8.162"/>
    <attribute defType="com.stambia.mail.outgoingServer.port" id="_okPzQJMkEeuaVLB2d1p41g" value="25"/>
    <configuration id="_kCjwsJZZEeuaVLB2d1p41g" name="DESA"/>
  </node>
  <node defType="com.stambia.mail.mailingList" id="_uaRygJMkEeuaVLB2d1p41g" name="Destinatario">
    <attribute defType="com.stambia.mail.mailingList.toText" id="_0WocMJMkEeuaVLB2d1p41g">
      <values>abraham.peralta@inetum.world</values>
    </attribute>
  </node>
  <node defType="com.stambia.mail.message" id="_6_Mro5MkEeuaVLB2d1p41g" name="Informacion_mensaje">
    <attribute defType="com.stambia.mail.message.outgoingServer" id="_MYRQQJMlEeuaVLB2d1p41g" ref="#_WmOugpMkEeuaVLB2d1p41g?fileId=_WDa8YJMkEeuaVLB2d1p41g$type=md$name=SMTP%20Mail%20Server?"/>
    <attribute defType="com.stambia.mail.message.toRef" id="_QW3MwJMlEeuaVLB2d1p41g">
      <refs>#_uaRygJMkEeuaVLB2d1p41g?fileId=_WDa8YJMkEeuaVLB2d1p41g$type=md$name=Destinatario?</refs>
    </attribute>
    <attribute defType="com.stambia.mail.message.senderText" id="_TpcX0JMlEeuaVLB2d1p41g" value="alertasstambia@pacifico.com.pe"/>
  </node>
</md:node>