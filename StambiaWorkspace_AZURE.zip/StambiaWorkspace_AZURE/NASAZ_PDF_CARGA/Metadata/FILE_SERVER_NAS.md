<?xml version="1.0" encoding="UTF-8"?>
<md:node xmlns:md="http://www.stambia.com/md" defType="com.stambia.file.server" id="_5YteYI0jEeudt4TkWBKkhg" md:ref="platform:/plugin/com.indy.environment/technology/file/standard.file.md#UUID_TECH_FILE_MD?fileId=UUID_TECH_FILE_MD$type=md$name=File?">
  <node defType="com.stambia.file.directory" id="_5fUcsI0jEeudt4TkWBKkhg" name="TMP_REPLICA_CLOUD">
    <attribute defType="com.stambia.file.directory.path" id="_FtFWwI6oEeuxru5RhMJcwQ" value="\\pps-nas05\TMP_REPLICA_CLOUD\DataSalud"/>
    <configuration id="_mKtCwJZ2EeuuFLoH_iEI2Q" name="DESA">
      <attribute defType="com.stambia.file.directory.path" id="_niCpIZZ2EeuuFLoH_iEI2Q" value="/opt/nas/DataSalud"/>
    </configuration>
  </node>
</md:node>