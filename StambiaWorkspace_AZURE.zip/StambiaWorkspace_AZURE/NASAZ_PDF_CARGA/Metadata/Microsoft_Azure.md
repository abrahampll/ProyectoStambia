<?xml version="1.0" encoding="UTF-8"?>
<md:node xmlns:md="http://www.stambia.com/md" defType="com.stambia.azure.storage" id="_1BXesI2nEeuLxaorGWpVAg" name="Microsoft Azure Blob Storage" md:ref="../../global/azure.storage.tech#UUID_TECH_AZURE_STORAGE?fileId=UUID_TECH_AZURE_STORAGE$type=tech$name=Microsoft%20Azure%20Storage?">
  <attribute defType="com.stambia.azure.storage.module" id="_1BZT4I2nEeuLxaorGWpVAg" value="Microsoft Azure Storage"/>
  <attribute defType="com.stambia.azure.storage.storageEndpointUrl" id="_6blrsI2nEeuLxaorGWpVAg" value="https://starchivossaluddes0100.blob.core.windows.net"/>
  <attribute defType="com.stambia.azure.storage.storageSharedAccessSignature" id="_8K5tMI2nEeuLxaorGWpVAg" value="sv=2020-02-10&amp;ss=bfqt&amp;srt=sco&amp;sp=rwdlacupx&amp;se=2031-04-09T09:02:28Z&amp;st=2021-04-06T01:02:28Z&amp;spr=https&amp;sig=vwWf1hYj0gDlS10N7zrF%2Balm53795kV2HHhIDhkH%2FNU%3D"/>
  <attribute defType="com.stambia.azure.storage.azcopyCapMbps" id="_9Xy-II2nEeuLxaorGWpVAg" value="30"/>
  <attribute defType="com.stambia.azure.storage.azcopyCommandPath" id="_jKmKEI2qEeu6sNsiQrA_1w" value="/home/sertomstades/azcopy"/>
  <attribute defType="com.stambia.azure.storage.azcopyTimeout" id="_QFS9wJZpEeuuFLoH_iEI2Q" value="60000"/>
  <configuration id="_kYKusJblEeuuFLoH_iEI2Q" name="DESA"/>
  <node defType="com.stambia.azure.storage.container" id="_9X4dsI2nEeuLxaorGWpVAg" name="stamed"/>
</md:node>